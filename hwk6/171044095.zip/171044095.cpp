#include "GTUSet.h"
#include "GTUVector.h"
#include <iostream>
#include <memory>
#include <exception>
using namespace stl_gtu;
//Note that I included only since i implemented everything inside header files
void driver();//this is the only driver( it tests everything )
int main(){
  driver();//just one driver
  return 0;
}

void driver(){

  GTUSet<int> my_set;
  my_set.insert(5);
  std :: cout << "Size of my set after inserting one element is " << my_set.size() << std :: endl;
  my_set.erase( 5 );
  std :: cout << "Size of my set after erasing one element is " << my_set.size() << std :: endl;
  my_set.insert( 2 );
  my_set.insert( 4 );
  std :: cout << "Size of my set after adding two elements is " << my_set.size() << std :: endl;
  my_set.clear();
  std :: cout << "Size of my set after clearing is " << my_set.size() << std :: endl;
  std :: cout << "Checking if my_set is empty after clearing" << std :: endl;
  if( my_set.empty() )
    std :: cout << "It is empty" << std :: endl;
  else
    std :: cout << "It is not empty" << std :: endl;

  std :: cout << "Inserting 4 elements (5,2,4,5)where the first and the last are the same and it should throw an exception because that is not valid for sets" << std :: endl;
  my_set.insert( 5 );
  my_set.insert( 2 );
  my_set.insert( 4 );
  try{
    my_set.insert( 5 );
  }
  catch( bad_param& cought_exception ){
    cought_exception.info();
    std :: cout << "Can't insert duplicates" << std :: endl;
  }
  catch( int x ){
    std :: cout << "can't catch an cought_exception" << std :: endl;
  }

  GTUIterator<int> iterator;
  std :: cout << "Using find global function to find an iterator to value 2 " << std :: endl;
  iterator = find( my_set.begin(), my_set.end(), 2 );
  std :: cout << "Value of found iterator is " << *iterator << std :: endl;
  iterator = find_if( my_set.begin(), my_set.end(), isOdd );
  std :: cout << "Iterator of find_if 'isOdd' function is " << *iterator << std :: endl;
  iterator = find_if( my_set.begin(), my_set.end(), isEven );
  std :: cout << "Iterator of find_if 'isEven' is " << *iterator << std :: endl;
  std :: cout << "Using for_each to print the x2 value of every element" << std :: endl;
  for_each( my_set.begin(), my_set.end(), printx2 );
  std :: cout << "Checking if my_set is empty after inserting" << std :: endl;
  if( my_set.empty() )
    std :: cout << "It is empty" << std :: endl;
  else
    std :: cout << "It is not empty" << std :: endl;

  std :: cout << "Size of my set after adding four elements( one duplicate exception ) is " << my_set.size() << std :: endl;
  std :: cout << "Iterating using the GTUIterator and printing all the values (added 5,2,4,5 to set which does not take duplicates )" << std :: endl;
  for( GTUIterator< int > it = my_set.begin(); it != my_set.end(); ++it )
    std :: cout << *it << std :: endl;


  //Vector part HERE
  std :: cout << "Testing vector now " << std :: endl;

  GTUVector <int> my_vector;
  my_vector.insert( 5 );
  std :: cout << "Size of my_vector after inserting one element is " << my_vector.size() << std :: endl;
  my_vector.erase( 5 );
  std :: cout << "Size of my_vector after erasing one element is " << my_vector.size() << std :: endl;
  my_vector.insert( 2 );
  my_vector.insert( 4 );
  std :: cout << "Size of my_vector after adding two elements is " << my_vector.size() << std :: endl;
  my_vector.clear();
  std :: cout << "Size of my_vector after clearing is " << my_vector.size() << std :: endl;
  std :: cout << "Checking if my_vector is empty after clearing" << std :: endl;
  if( my_vector.empty() )
    std :: cout << "It is empty" << std :: endl;
  else
    std :: cout << "It is not empty" << std :: endl;

  my_vector.insert( 5 );
  my_vector.insert( 2 );
  my_vector.insert( 4 );
  my_vector.insert( 5 );

  std :: cout << "Size of my vector after adding four elements is " << my_vector.size() << std :: endl;
  std :: cout << "Iterating using the GTUIteratorConst( CONST ) this time( this calles begin() function, end() function and ++ for iterator ) and printing all the values (added 5,2,4,5 to vector which does take duplicates )" << std :: endl;
  for( GTUIteratorConst< int > it = my_vector.begin(); it != my_vector.end(); ++it )
    std :: cout << *it << std :: endl;


  std :: cout << "Executing global functions for iterators with my_vector.begin() and my_vector.end()" << std :: endl;
  std :: cout << "Using find global function to find an iterator to value 2 " << std :: endl;
  iterator = find( my_vector.begin(), my_vector.end(), 2 );
  std :: cout << "Value of found iterator is " << *iterator << std :: endl;
  iterator = find_if( my_vector.begin(), my_vector.end(), isOdd );
  std :: cout << "Iterator of find_if 'isOdd' function is " << *iterator << std :: endl;
  iterator = find_if( my_vector.begin(), my_vector.end(), isEven );
  std :: cout << "Iterator of find_if 'isEven' is " << *iterator << std :: endl;
  std :: cout << "Using for_each to print the x2 value of every element" << std :: endl;
  for_each( my_vector.begin(), my_vector.end(), printx2 );
  std :: cout << "Checking if my_vector is empty after inserting" << std :: endl;
  if( my_vector.empty() )
    std :: cout << "It is empty" << std :: endl;
  else
    std :: cout << "It is not empty" << std :: endl;
  std :: cout << "Changing tha value of [0] index to 91 for vector" << std :: endl;
  my_vector[0] = 91;
  std :: cout << "Value after calling my_vector[0] = 91 is " << my_vector[0] << std :: endl;

 for( GTUIterator< int > it = my_vector.begin(); it != my_vector.end(); ++it )
   std :: cout << *it << std :: endl;
   std :: cout << std :: endl;
  std :: cout << "My vector begin is " << my_vector[0] << std :: endl;
  GTUIterator< int > it5 = my_vector.begin();
  std :: cout << "My vector begin is (using -> operator)" << it5->el << std :: endl;
  std :: cout << "Using -> operator to change value to 1 through iterator of the beginning of my_vecotr " << std :: endl;
  it5->el = 1;
  std :: cout << "My vector begin is now (using -> again ): " << it5->el << std :: endl;
  std :: cout << "Calling vector's function insert witl 14 with iterator to first position as a parameter( this was not actually written in the pdf but i decided to implement also this one since everyone implemented it, i am not sure if this function was necessary )" << std :: endl;
  GTUIterator<int> scnd_third = my_vector.begin();
  my_vector.insert( 14, my_vector.begin() );
  for( GTUIteratorConst<int> itr = my_vector.begin(); itr != my_vector.end(); itr++ )
    std :: cout << *itr << std :: endl;

  std :: cout << "Calling vector's function insert with 51 with iterator to third position as a parameter( this was not actually written in the pdf but i decided to implement also this one since everyone implemented it, i am not sure if this function was necessary )" << std :: endl;
  GTUIterator<int> iterator_third = my_vector.begin();
  ++iterator_third; ++iterator_third;
  my_vector.insert( 51,  iterator_third );

  for( GTUIteratorConst<int> itr = my_vector.begin(); itr != my_vector.end(); itr++ )
    std :: cout << *itr << std :: endl;



  std :: cout << "Making a char vector now to show it works with chars or anything else also" << std :: endl;
  GTUVector<char> my_vec;
  std :: cout << "Inserting a here" << std :: endl;
  my_vec.insert('a');
  std :: cout << "Letter in our vector is " << my_vec[0] << std :: endl;


  std :: cout << "Printing my_vector now using GTUIteratorConst iterator and using postincrement" << std :: endl;
  for( GTUIteratorConst<int> itr = my_vector.begin(); itr != my_vector.end(); itr++ )
    std :: cout << *itr << std :: endl;

  GTUIteratorConst< int > iter = my_vector.begin();

  std :: cout << "Using ++ preincrement operator iterator points to " << *++iter << std :: endl;
  std :: cout << "Using -- predecrement operator iterator points to " << *--iter << std :: endl;
  std :: cout << "Using ++ postincrement operator iterator points to " << *iter++ << std :: endl;
  std :: cout << "Using -- postdecrement operator iterator points to " << *iter-- << std :: endl;
  std :: cout << "After exectuing postdecremented it points to " << *iter << std :: endl;
  GTUIteratorConst<int> iter2 = my_vector.begin();
  std :: cout << "Comparing two iterators that point to the same node " << std :: endl;
  if( iter2 == iter )
    std :: cout << "They are equal " << std :: endl;
  else
    std :: cout << "They are not equal " << std :: endl;

  std :: cout << "Now incrementing one of them" << std :: endl;
  ++iter;
  std :: cout << "Comparing again" << std :: endl;
  if( iter == iter2 )
    std :: cout << "They are equal" << std :: endl;
  else
    std :: cout << "They are not equal" << std :: endl;

  std :: cout << "Iter1 = " << *iter << std :: endl;
  std :: cout << "Iter2 = " << *iter2 << std :: endl;
  std :: cout << "Assigning iter1 to iter 2 " << std :: endl;
  iter = iter2;
  std :: cout << "After assignment" << std :: endl;
  std :: cout << "Iter1 = " << *iter << std :: endl;
  std :: cout << "Iter2 = " << *iter2 << std :: endl;

  std :: cout << "End of the driver function" << std :: endl;

  return;
}
