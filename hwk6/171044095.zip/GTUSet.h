#ifndef GTUSET_H
#define GTUSET_H
#include "GTUContainer.h"
#include <bits/stdc++.h>
#include <exception>
namespace stl_gtu{

/*
Set is implemented using the linked list I have written using shared pointers
I didn't order them since yusuf hoca said there is no need for such a Thing but since i implemented it using double linked list inserting things in oreder is very easy to write
*/
class bad_param{
public:
  bad_param(){}
  void info(){ std :: cout << "Incorrect parameter, exception cought" << std :: endl; }
};//this is used just to be able to throw an exception since such a thing is not predefined in c++'s library
template < typename T >
class GTUSet{
public:
  virtual ~GTUSet(){ this -> clear(); }//this deallocates all the data after the created object goes out of scope
  bool empty()const noexcept { return my_data.get()->empty(); }//checks if empty
  void insert( const T& el );//this function will throw an exception
  bool erase( const T& el ) noexcept{ return my_data.get()->erase( el ); }//erases a given element by calling linked list's erase function
  void clear() noexcept{ my_data.get()->clear(); }//clears the memeory
  unsigned int size()const noexcept{ return my_data.get()->getSize(); }//gives the size
  unsigned int max_size()const noexcept{ return max_size_; }//returns the max size
  const GTUIterator<T> begin()const noexcept{ return GTUIterator< T >( my_data.get() -> head ); }//just returns the iterator after  constructing it
  const GTUIterator<T> end()const noexcept{ return GTUIterator< T >( nullptr ); }//just returns the iterator after  constructing it

protected:
  static const int max_size_ = UINT_MAX;
  std :: shared_ptr < LList < T > > my_data{ new LList< T > };//pointing to my list
};

template < typename T >
void GTUSet< T > :: insert( const T& el ){//no duplicates allowed
  bool found = false;
  if( size() >= max_size() )//if it reaches the maximum size and won't insert
    found = true;

  for( GTUIterator < T > it = this -> begin(); !found && it != this -> end(); ++it ){//iterating through the linked list using iterator and inserts an element if there is no duplicates
    if( *it == el ){
      found = true;
    }
  }

  if( !found )
    this -> my_data.get() -> insert( el );//size is taken care of inside the linked list
  else
    throw bad_param();

  return;
}

}//end of namespace
#endif
