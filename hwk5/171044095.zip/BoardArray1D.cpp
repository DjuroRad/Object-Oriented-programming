#include "BoardArray1D.h"
namespace boardgtu{

BoardArray1D :: BoardArray1D( int rows, int cols ):AbstractBoard( rows, cols ){
  allocatePuzzleAndReset();
}

BoardArray1D :: ~BoardArray1D(){
  delete[] puzzle;
  puzzle = nullptr;
}

BoardArray1D :: BoardArray1D( const BoardArray1D& obj ){
  AbstractBoard :: setSize( obj.getRows(), obj.getCols() );//sets new size for the puzzle, avoiding unnecessary reseting this way
  allocatePuzzle();//allocated it dynamically
  //setting other values now
  setEmptyCol( obj.getEmptyCol() );
  setEmptyRow( obj.getEmptyRow() );
  setNumberOfMoves( obj.NumberOfMoves() );
  setLastMove( obj.lastMove() );

  for( int i = 0; i < getRows(); ++i )
    for( int j = 0; j < getCols(); ++j )
      (*this)( i, j ) = obj( i, j );
}

const BoardArray1D& BoardArray1D :: operator = ( const BoardArray1D& rightSide ){
  if( this != &rightSide ){
    delete[] puzzle;

    AbstractBoard :: setSize( rightSide.getRows(), rightSide.getCols() );//sets new size for the puzzle, avoiding unnecessary reseting this way
    allocatePuzzle();//allocated it dynamically

    setEmptyCol( rightSide.getEmptyCol() );
    setEmptyRow( rightSide.getEmptyRow() );
    setNumberOfMoves( rightSide.NumberOfMoves() );
    setLastMove( rightSide.lastMove() );

    for( int i = 0; i < getRows(); ++i )
      for( int j = 0; j < getCols(); ++j )
        (*this)( i, j ) = rightSide( i, j );
  }

  return *this;
}

void BoardArray1D :: setSize( int rows, int columns ){
  AbstractBoard :: setSize( rows, columns );
  allocatePuzzleAndReset();
}
int BoardArray1D :: operator()( int row, int column )const{
  if( row >= 0 && row < getRows() && column >= 0 && column < getCols() )
    return puzzle[ row * getCols() + column ];// mimicing 2D array so that it would work in AbstractClass for polymorphism since other derived classes are 2D array/vector
  else exit( 1 );//it says we need to terminate a program, i would use exception but since we didn't learn i'll just use exit here
}

int& BoardArray1D :: operator()( int row, int column ){
  if( row >= 0 && row < getRows() && column >= 0 && column < getCols() )
    return puzzle[ row * getCols() + column ];// mimicing 2D array so that it would work in AbstractClass for polymorphism since other derived classes are 2D array/vector
  else exit( 1 );//it says we need to terminate a program, i would use exception but since we didn't learn i'll just use exit here
}

void BoardArray1D :: allocatePuzzle(){
  puzzle = new int[ getRows()*getCols() ];
  fill( puzzle, puzzle + getCols()*getRows(), (int)EMPTY_CELL );
}

}
