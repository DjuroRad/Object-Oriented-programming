#ifndef BOARDARRAY1D_H
#define BOARDARRAY1D_H

#include "AbstractBoard.h"
using std :: fill;
namespace boardgtu{
class BoardArray1D : public AbstractBoard{
  public:
    BoardArray1D( int rows = DEF_ROWS, int cols = DEF_COLS );
    ~BoardArray1D();//destructor
    BoardArray1D( const BoardArray1D& obj );//copy constructor
    const BoardArray1D& operator = ( const BoardArray1D& rightSide );//assignment operator overloaded

    void setSize( int rows, int columns ) override;
    int operator()( int row, int column )const override final;
    int& operator()( int row, int column ) override final;

  private:
    void allocatePuzzle() override final;
    int* puzzle = nullptr;

};

}
#endif
