#include "AbstractBoard.h"

namespace boardgtu{
int AbstractBoard :: number_of_boards = 0;//only static non-const variable

void AbstractBoard :: setSize( int rows, int cols ){//It is made sure that in every overloaded setSize this one is called and afterwards the reset and allocation are called

   if( rows < DEF_ROWS )
    ROWS = DEF_ROWS;//defaulting it if smaller than 3, our smallest board was 3 in previous homeworks
   else
    ROWS = rows;

   if( cols < DEF_COLS )
    COLUMNS = DEF_COLS;//same as for rows
   else
    COLUMNS = cols;

  return;
}

ostream& operator <<( ostream& output, const AbstractBoard& board_obj ){
  output << endl; //just one newline for indentation
  for( int i = 0; i < board_obj.getRows(); i++ ){
    for( int j = 0; j < board_obj.getCols(); j++ ){
      if( board_obj( i, j ) != board_obj.EMPTY_CELL ) output << board_obj( i, j ) << "\t";
      else output << " " << "\t";
    }
    output << endl << endl << endl << endl;//used for indentation only
  }

  return output;
}

bool AbstractBoard :: writeToFile( string file_name ) const{//works the same as it did in previous assignments, mostly self-explainatory
    bool possible = true;

    string number = "00";
    string empty_cell_string = "bb";
    fstream myfile;
    myfile.open( file_name, ios :: out );
    if( !myfile.fail() ){
      for( int i = 0; i < ROWS; ++ i ){
        for( int j = 0; j < COLUMNS; ++ j ){
          if( (*this)(i,j) != EMPTY_CELL ){
            number[1] = '0' + (*this)(i,j) % 10;//or this -> operator()(i,j) can also be used
            number[0] = '0' + (*this)(i,j) / 10;
            myfile << number;
          }
          else myfile << empty_cell_string;
          myfile << " ";
        }
        myfile << endl;
      }
      myfile.close();
    }
    else possible = false;

    return possible;
}

bool AbstractBoard :: isSolved()const{
  bool solved = true;
  if( (*this)( ROWS -1, COLUMNS - 1 ) == EMPTY_CELL ){//avoids overhead in some cases
    for( int x = 1, i = 0; i < ROWS && solved; ++i ){
      for( int j = 0; j < COLUMNS && solved; ++j ){
        if( (*this)(i,j) != EMPTY_CELL && (*this)( i,j ) != IMPOSSIBLE_MOVE ){//skips incrementing of right value for empty cell and impossible move when checking, self-explainatory
          if( (*this)(i,j) != x )solved = false;
          ++x;
        }
      }
    }
  }else solved = false;

  return solved;
}

bool AbstractBoard :: operator == ( const AbstractBoard& rightSide ){//check rows and cols first to avoid overhead and than afterwards checks everything else
  bool equal = true;
  if( COLUMNS == rightSide.getCols() && ROWS == rightSide.getRows() ){
    for( int i = 0; i < COLUMNS && equal; ++i ){//simple nested loop checking one by one every cell
      for( int j = 0; j < ROWS && equal; ++j ){
        if( (*this)( i, j ) != rightSide( i, j ) )
          equal = false;
      }
    }
  }else equal = false;

  return equal;
}

bool AbstractBoard :: readFromFile( ifstream& myfile ){//same as before just overriden virtual () operator used to change values inside out puzzle

    bool success = false;

    string row_of_text;
    int row_count = 0;
    while( getline( myfile, row_of_text ) )//calculating the number of rows in a file
      ++ row_count;
    //goes back to the beginning of the file to calculate the number of COLUMNS
    myfile.clear();
    myfile.seekg( 0, ios::beg );
    string element;
    int element_count = 0;
    while( myfile >> element)//finds the number of total elements inside the file
      ++element_count;

    setSize( row_count, element_count/row_count );//element_cout / ROWS is actually the number of columns
    //again go to the beginning of the file and read element by element and at the same time update the puzzle
    myfile.clear();
    myfile.seekg( 0, ios :: beg );
    const string impossible_move = "00";
    const string empty_cell = "bb";
    int i = 0, j = 0;
    while( myfile >> element ){
      if( element != empty_cell ){
        if( element != impossible_move)
          (*this)( i, j ) = stoi( element );
        else
          (*this)( i, j ) = IMPOSSIBLE_MOVE;
      }
      else{
        (*this)( i, j ) = EMPTY_CELL;
        empty_row = i;
        empty_col = j;
      }
      ++j;//increment the position
      if( j == COLUMNS ){//update accordingly
        j = 0;
        ++i;
      }
    }
    success = true;

  setNumberOfMoves( 0 );//reseting it to initial value
  return success;
}
void AbstractBoard :: reset(){//gets the board to the solution
  for( int i = 0, x = 1; i < getRows(); ++ i ){//x represent the number to be filled in order
    for( int j = 0; j < getCols(); ++j ){
      if( ( *this )( i,j ) != IMPOSSIBLE_MOVE ){
        ( *this )( i, j ) = x;
        ++x;
      }
    }
  }
  setEmptyRow( getRows() - 1 );
  setEmptyCol( getCols() - 1 );
  ( *this )( getEmptyRow(), getEmptyCol() ) = EMPTY_CELL;//empty cell to be in the last place
  setNumberOfMoves( 0 );//reseting it to 0 now when we reset the board as we did in previous assignments
  setLastMove('S');
  return;
}

bool AbstractBoard :: move( char move ){
  bool valid_move = false;
  string error_message = "Error. Chosen move is not possible.";
  int target_row = empty_row, target_col = empty_col;
  switch ( move ) {
    case 'U':
      -- target_row;
      break;
    case 'D':
      ++ target_row;
      break;
    case 'L':
      -- target_col;
      break;
    case 'R':
      ++ target_col;
      break;
  }
  if( target_row >= 0 && target_row < ROWS && target_col >= 0 && target_col < COLUMNS && (*this)( target_row, target_col ) != IMPOSSIBLE_MOVE ){
      valid_move = true;
      int temp = (*this)( target_row, target_col );//swaping values using overridden protected () operator that returns a reference to data to be altered
      (*this)( target_row, target_col ) = EMPTY_CELL;
      (*this)( empty_row, empty_col ) = temp;
      empty_row = target_row;//updating empty_row and column also
      empty_col = target_col;
      ++number_of_moves;
      setLastMove( move );
  }
  else cerr << error_message << endl;

  return valid_move;
}

void AbstractBoard :: allocatePuzzleAndReset(){//function is same for derived classes and is used in them if they have dynamic elents inside
  allocatePuzzle();
  reset();
}
//global function implementation
bool valid_sequence_of_moves( AbstractBoard* boards[], const int size ){
  bool valid = true;//assumption
  int prev_empty_row, prev_empty_col;//we need to be able to check which move was made
  int current_empty_row, current_empty_col;//we need to be able to check which move was made
  if( size > 0 ){//returning false if the size is 0
    if( boards[ size -1 ] -> isSolved() ){//after last move it needs to be solved otherwise we immediatelly know that this arrray won't lead to the solution
      for( int i = 0; valid && i < size - 1 ; ++i ){//now checking for validity of every next move
        int j = i + 1;//checking with the next_move board
        if( boards[ i ] -> getRows() == boards[ j ] -> getRows() && boards[ i ] -> getCols() == boards[ j ] -> getCols() ){//making sure rows and cols are the same first
          //checking if the empty cell moved properly to its new position( verticlaly or horizontally )
          if( ( boards[ i ] -> getEmptyCol() == boards[ j ] -> getEmptyCol() &&
              ( boards[ j ] -> getEmptyRow() == boards[ i ] -> getEmptyRow() + 1 || boards[ j ] -> getEmptyRow() == boards[ i ] -> getEmptyRow() - 1 ) ) || //this checks if it moves up/down
              ( boards[ i ] -> getEmptyRow() == boards[ j ] -> getEmptyRow() &&
              ( boards[ j ] -> getEmptyCol() == boards[ i ] -> getEmptyCol() + 1 || boards[ j ] -> getEmptyCol() == boards[ i ] -> getEmptyCol() - 1 ) )//this checks if it moves left/right
            ){//if condition body here
            if( (*boards[ i ])( boards[ j ] -> getEmptyRow(), boards[ j ] -> getEmptyCol() ) == boards[0]->getImpossibleMove() || ( *boards[ j ] )( boards[ i ] -> getEmptyRow(), boards[ i ] -> getEmptyCol() ) == boards[0]->getImpossibleMove() ) //indicates special case that would be able to appear only for puzzles read from file including 0s or impossible moves inside. Since we do not control two empty cells for equal numbers 0 in these places can occur yileding an incorrect result that would pass as correct if both of them are 0, but would avoid overhead if only one is 0
              valid = false;//can not make move due to impossible move
            //now checking if all the numbers are at the right position
            for( int k = 0; k < boards[ i ] -> getRows() && valid; ++ k ){//checking here if all other cells are at the same positions
              for( int m = 0; m < boards[ i ] -> getCols() && valid; ++ m ){
                if( !(k ==  boards[ i ] -> getEmptyRow() && m == boards[ i ] -> getEmptyCol() ) && !( k ==  boards[ j ] -> getEmptyRow() && m == boards[ j ] -> getEmptyCol() ) ){//here if there are for example 9 cells, we will check 7 of them. Since we know empty cell is at correct position( we already checked with the previous if ) we know that 8 of them are at the correct position meaning that the one position left will be correct position for the only position we did not check
                  if( ( *boards[ i ] )( k, m ) != ( *boards[ j ] )( k, m ) ){//other numbers are not at their correct positions
                    valid = false;
                  }
                }
              }
            }
          }else valid = false;//not a valid move, either not vertial or not horizontal move of the empty_cell
        }else valid = false;//rows and cols are not the same
      }
    }else valid = false;//last element of the array is not solved
  }else valid = false;//board array is empty

  return valid;
}

}//end of namespace
