#ifndef NPUZZLE_H
#define NPUZZLE_H
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <ctime>
using namespace std;
//code goes here
class NPuzzle{

public:
  bool readFromFile( string file_name ){ return board_obj.readFromFile( file_name ); }
  void setSize( int ROWS, int COLUMNS ){ board_obj.setSize( ROWS, COLUMNS ); board_obj.reset(); shuffle( ROWS * COLUMNS ); }
  void print() const{ board_obj.print(); }
  char moveIntelligent(){ return board_obj.move( 'I' ); }
  void moveRandom(){ board_obj.move( 'P' ); }//P za potez, nasumicni potez
  void reset(){ board_obj.reset(); };
  void move( char move );
  void solvePuzzle();
  void shuffle( int N );
  void printReport() const;
  char getMoveFromUser() const;
  int setSizeInput() const;
  bool isValidNum( char c ) const;
private:
  class Board{

  public:

    Board(){
      //setSize();//defaults it to three
      for( auto &row : puzzle ){//just setting puzzle to initial value
        for( auto &col : row )
          col = EMPTY_CELL;
        }
    }
    Board( string file_name ){
      if( !readFromFile( file_name ) )
        Board();//setting it to the size of the user's input value
    }
    void print() const;
    bool writeToFile( string file_name) const;
    void reset();
    bool readFromFile( string file_name );
    void setSize( int ROWS, int COLUMNS ){ this -> ROWS = ROWS; this -> COLUMNS = COLUMNS; setSolvedPuzzle(); }
    bool move( char move );
    bool isSolved() const{ bool success; manhattanDistance() == 0 ? success = true : success = false; return success; }//just calles manhattanDistance function
    static int getRows() { return NPuzzle :: Board :: ROWS; }
    static int getCols() { return COLUMNS; }
    char getLastMove() const { return last_move; }
  private:
    int manhattanDistance() const;
    int distanceToGoal( int row, int col, int target ) const;
    void setSolvedPuzzle();
    bool moveDirectional( char move );
    bool validMove ( int target_row, int target_col ) const;
    void updatePuzzle( int target_row, int target_col );
    void setTarget( int& row, int& col, char move ) const;
    char setIntelligentDirection();
    char setRandomDirection() const;
    char directionItoChar( int num )const;
    static const int MAX = 9;// same for every object
    static const int EMPTY_CELL = -1;// same for every object
    static const int IMPOSSIBLE_MOVE = 0;// same for every object
    static int solved_puzzle[ MAX ][ MAX ];
    static int empty_row_sp, empty_col_sp;
    static int ROWS, COLUMNS;
    char last_move = 'N';
    int puzzle[ MAX ][ MAX ];
    int empty_row, empty_col;
  };

private:
  char getInvMove( char move ) const ;
  string getFileNameFromUser() const;
  Board board_obj;
  const static int MAX = 9;
  const int DEFAULT_ROWS = 3;//represents the minumun number of rows at the same time
  const int DEFAULT_COLUMNS = 3;
  int move_count = 0;
  friend ostream &operator << ( ostream& output, const NPuzzle :: Board& board_obj );//it needs to be friend with both of these classes to be able to have full access
};
#endif
