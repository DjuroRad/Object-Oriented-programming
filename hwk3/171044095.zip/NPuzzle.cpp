#include "NPuzzle.h"
int NPuzzle :: Board :: ROWS = 0;
int NPuzzle :: Board :: COLUMNS = 0;
int NPuzzle :: Board :: solved_puzzle[MAX][MAX];
int NPuzzle :: Board :: empty_col_sp = 0;
int NPuzzle :: Board :: empty_row_sp = 0;

void NPuzzle :: move( char move ){
  switch ( move ) {
    case 'R':
    case 'L':
    case 'U':
    case 'D':
      if ( board_obj.move( move ) )
        ++ move_count;
      break;
    case 'O':
      {
      string file_name = getFileNameFromUser();
      if( board_obj.readFromFile( file_name ) )
        move_count = 0;
      }
      break;
    case 'E':
      {string file_name = getFileNameFromUser();
      board_obj.writeToFile( file_name );}
      break;
    case 'V':
      solvePuzzle();
      break;
    case 'S':
      shuffle(  board_obj.getRows() * board_obj.getCols() );
      move_count = 0;
      break;
    case 'I':
      if( moveIntelligent() ){
        move_count++;
        cout << "Intelligent move to " << board_obj.getLastMove() << endl;
      }
      break;
      case 'P':
      moveRandom();
    case 'T':
      printReport();
      break;
  }
}

void NPuzzle :: solvePuzzle(){
  char curr_move = 'N', prev_move = 'N', inverse_move = 'N';
  int num_of_moves_comp = 0;
  const int MAX_MOVES = 100000;
  while( !board_obj.isSolved() && num_of_moves_comp <= MAX_MOVES ){
    moveIntelligent();
    curr_move = board_obj.getLastMove();
    inverse_move = getInvMove( curr_move );
    ++ num_of_moves_comp;
    cout << "Move to " << board_obj.getLastMove() << endl;
    print();

    if( prev_move == inverse_move ){//means it started repeating the intelligent move
      int rand_moves = board_obj.getRows() + board_obj.getCols();
      for( int i = 0; i < rand_moves && !board_obj.isSolved() ; ++ i ){
        moveRandom();
        cout << "Move to " << board_obj.getLastMove() << endl;
        print();
        ++ num_of_moves_comp;
        }

      prev_move = 'N';//reseting it
    }
    else{
      prev_move = curr_move;
      ++ num_of_moves_comp;
    }
  }

  if( num_of_moves_comp > MAX_MOVES )
    cout << "Unfortuntely, our algorithm has reached the maximum number of moves." << endl << "You can try solving it again or shuffling it and than solving it" << endl << "Good luck!" << endl;

  move_count += num_of_moves_comp;
  cout << " V command executed " << endl;
  return;
}

void NPuzzle :: shuffle( int N ){
  for( int i = 0; i < N; ++i )
    moveRandom();

  if( board_obj.isSolved() )
    moveRandom();

  return;
}

char NPuzzle :: getInvMove( char move ) const {
  char inv_move = 'N';
  switch( move ){
    case 'D':
      inv_move = 'U';
      break;
    case 'U':
      inv_move = 'D';
      break;
    case 'L':
      inv_move = 'R';
      break;
    case 'R':
      inv_move = 'L';
      break;
  }

  return inv_move;
}

void NPuzzle :: printReport()const{
  cout << "Number of moves: " << move_count << endl;
  if( board_obj.isSolved() )
    cout << "Problem is solved!" << endl;
  else
    cout << "Problem is not solved" << endl;

  return;
}

string NPuzzle :: getFileNameFromUser()const{
    string info = "Please enter the name of your file ( Note that if you input your file name with spaces only the first word will be taken as file name ): ";
    cout << info;
    string line;
    string file_name;
    getline( cin, line );
    while( line.size() == 0 ){//pressing enter would yield not putting anything in our string
      cout << "Error. Please enter a valid name" << endl;
      getline( cin, line );
    }
    size_t i = line.find_first_of( ' ' );
    file_name = line.substr( 0, i );

    return file_name;
}

bool NPuzzle :: isValidNum( char c )const {
    bool res = false;
    const int MIN_ROWS = 3;
    const int MAX_ROWS = 9;
    if( c >= MIN_ROWS + '0' && c <= MAX_ROWS + '0') res = true;// >= '3' since our minimum puzzle board will be 3x3

    return res;
}

int NPuzzle :: setSizeInput()const{//number of rows and columns is the same when user is setting the size
  const int CORRECT_INPUT_LENGTH = 1;
  string input;//taking the whole line from the user so that I could manipulate the user input if there are errors
  string error_message = "Please only include 1 integer digit bigger than 2 ( 3, 4, 5 ... 9 ) in your input";
  string question_for_user = "Please enter the problem size";

  cout << question_for_user << endl;
  getline( cin, input );

  while( !isValidNum( input[ 0 ] ) || input.length() != CORRECT_INPUT_LENGTH ){
    cout << error_message << endl;
    cout << question_for_user << endl;
    getline( cin, input );
  }
  int rows_user = input[ 0 ] - '0';

  return rows_user;
}

char NPuzzle :: getMoveFromUser()const{

  char user_move = 'N';//n is for none
  const int input_size = 1;
  string input;

  string error_message = "Error: Invalid input. Input examples: 'T', 'S', 'V', 'E', 'O', 'L', 'R', 'U', 'D'.\n Please try again: ";
  while( user_move == 'N' ){
    cout << "Your move: ";
    getline( cin, input );
    if( input.length() == input_size ){
      switch ( input[0] ) {
        case 'L':
        case 'R':
        case 'D':
        case 'U'://directional ones
        case 'S'://suffle
        case 'Q'://quit
        case 'I'://Intelligent
        case 'T'://printReport
        case 'O'://readFromFile
        case 'V'://solve
        case 'E'://write to file
          user_move = input[ 0 ];
          break;
        default:
         cerr << error_message << endl;
          break;
      }
    }

  }
  return user_move;
}
