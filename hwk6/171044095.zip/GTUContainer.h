#ifndef GTUCONTAINER_H
#define GTUCONTAINER_H

#include "Iterators.h"
namespace stl_gtu{
template < typename T >
class GTUContainer{//our structres derive from this block
public:
  virtual bool empty()const noexcept = 0;//test whether container is empty
  virtual unsigned int size()const noexcept = 0;//return container size, they say in homework it has to be virtual but i don't get it why
  virtual unsigned int max_size()const noexcept = 0;//return maximum size
  virtual void insert( const T& el ) = 0;//throws exception bad_pafram
  virtual bool erase( const T& el ) noexcept = 0;//erases an element
  virtual void clear() noexcept = 0;//clears all the content
  virtual const GTUIterator<T> begin() noexcept = 0;//return iterator to begining
  virtual GTUIterator<T> end() noexcept = 0;//return iterator to end
};
}//end of namespace
#endif
