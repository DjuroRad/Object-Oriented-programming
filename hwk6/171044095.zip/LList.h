#ifndef LLIST_H
#define LLIST_H
#include <iostream>
#include <memory>

namespace stl_gtu{
template < typename T >
struct Node{
    std :: shared_ptr< Node <T> > next{nullptr};
    std :: shared_ptr< Node <T> > prev{nullptr};
    T el;
};

template< typename T >
class LList{
public:
  virtual ~LList(){ clear(); }
  std :: shared_ptr< Node<T> > head{nullptr};
  std :: shared_ptr< Node<T> > tail{nullptr};
  unsigned int size = 0;
  bool insert( const T& );//there functions are called inside the set class
  bool insert( const T&, int pos );//there functions are called inside the set class
  bool erase ( const T& );//there functions are called inside the set class
  void clear ();
  bool empty()const;
  unsigned int getSize()const{ return size; }
};

template < typename T >
bool LList< T > :: erase( const T& to_erase){
  bool success = true;
  std :: shared_ptr< Node< T > > temp = head;
  while( temp.get() != nullptr && temp.get() -> el != to_erase )
    temp = temp.get()->next;

  if( temp.get() == nullptr ){
    success = false;
  }
  if( success == true ){//meaning element was found
    if( temp.get() == head.get() )
      head = temp.get()->next;

    if( (temp.get()->prev).get()  != nullptr )//if temp is pointing to head
      (temp.get()->prev).get()->next = temp.get() -> next;
    else
      head = temp.get()->next;
    if( (temp.get() -> next).get() != nullptr )//if temp is pointing to the tail
      (temp.get()->next).get()->prev = temp.get() -> prev;
    else
      tail = temp.get()->prev;

    temp = nullptr;
    --size;
  }

  return success;
}
template < typename T >
bool LList< T > :: insert( const T& new_el ){//inserts an element to the last position
  bool success = true;
  std :: shared_ptr< Node < T > > new_tail( new Node < T > );
  if( new_tail.get() == nullptr )
    success = false;//if allocation fails( no memory )
  else{
    new_tail.get() -> el = new_el;
    new_tail.get() -> next = nullptr;
    new_tail.get() -> prev = tail;
    if( size == 0 )
      tail = head = new_tail;
    else{
      tail -> next = new_tail;
      tail = new_tail;
    }
    ++size;
  }
  return success;
}

template < typename T >
bool LList< T > :: insert( const T& new_el, int pos ){//there functions are called inside the set class
  std :: shared_ptr< Node<T> > new_node ( new Node < T > );
  std :: shared_ptr< Node<T> > temp = head;
  new_node.get()->el = new_el;
  for( int i = 0; i < pos; ++i )
    temp = temp.get() -> next;
  if( pos != 0){//other cases
    std :: shared_ptr< Node < T > > prev_node = temp.get() -> prev;

    new_node.get() -> next = temp;//new node's next pointing to current node
    new_node.get() -> prev = prev_node;//new node's prev pointing to prev_node of current node
    temp.get()->prev.get()->next = new_node;//previous node's next is now pointing to new_node
    temp.get()->prev = new_node;//also current node's prev is pointing to new_node
  }
  else{//case when it is added to the first element
    head.get() -> prev = new_node;
    new_node.get()->next = head;
    new_node.get()->prev = head.get()->prev;//null = null actually here
    head = new_node;//new head is now new node
  }
  ++size;
}
template < typename T >
void LList< T > :: clear(){
  std :: shared_ptr < Node < T > > temp;
  for( int i = 0; i< size; ++i ){
    // erase( temp.get()->el );
    temp = head;
    head = head.get()->next;
    temp.get()->next = nullptr;//this way the count of the shared pointer decreases causing the destructor to be called
    temp.get()->prev = nullptr;//this way the count of the shared pointer decreases causing the destructor to be called
  }
  size = 0;
  return;
}
template < typename T >
bool LList< T > :: empty()const{//checks if empty or not
  if( size == 0 )
    return true;
  else
    return false;
}
}

#endif
