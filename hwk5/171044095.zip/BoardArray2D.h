#ifndef BOARDARRAY2D_H
#define BOARDARRAY2D_H

#include "AbstractBoard.h"

using std :: fill;
namespace boardgtu{

class BoardArray2D : public AbstractBoard{
  public:
    BoardArray2D( int rows = DEF_ROWS, int cols = DEF_COLS );
    ~BoardArray2D();//destructor
    BoardArray2D( const BoardArray2D& obj );//copy constructor
    const BoardArray2D& operator = ( const BoardArray2D& rightSide );//assignment operator overloaded

    void setSize( int rows, int columns ) override;
    int operator()( int row, int column )const override final;
    int& operator()( int row, int column ) override final;

  private:
    void allocatePuzzle() final;
    int** puzzle = nullptr;
};

}//end of namespace
#endif
