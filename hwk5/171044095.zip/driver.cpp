#include "BoardVector.h"
#include "BoardArray1D.h"
#include "BoardArray2D.h"
using namespace boardgtu;
void driverBoardArray1D();
void driverBoardArray2D();
void driverBoardVector();
void driverGlobalFunc();
int main(){
  bool quit = false;
  int choice = -1;
  while( !quit ){
    cout << "1 - driverBoardArray1D" << endl;
    cout << "2 - driverBoardArray2D" << endl;
    cout << "3 - driverBoardVector" << endl;
    cout << "4 - global func driver" << endl;
    cout << "0 - quit" << endl;
    cin >> choice;
    switch( choice ){
      case 1:
        driverBoardArray1D();
        break;
      case 2:
        driverBoardArray2D();
        break;
      case 3:
        driverBoardVector();
        break;
      case 4:
        driverGlobalFunc();
        break;
      case 0:
        quit = true;
        break;
      default:
        cout << "Error, such option does not exist " << endl;
    }
  }
}
void driverGlobalFunc(){
  BoardVector board_vector;
  BoardArray1D board_array_1d;
  board_array_1d.move( 'U' );
  BoardArray2D board_array_2d;
  cout << "Boards are" << endl;
  cout << board_vector << board_array_1d << board_array_2d;
  AbstractBoard* arr[3] = { &board_vector, &board_array_1d, &board_array_2d };
  if( valid_sequence_of_moves( arr, 3 ) == true ) cout << "MOVES TO SOLUTION ARE VALID" << endl;
  else cout << "they are not valid "<<endl;
  cout << " Adding one more element " << endl;
  BoardVector added_element( 3, 3 );
  cout << "Added board " << endl;
  added_element.print();
  AbstractBoard* arr2[4] = { &board_vector, &board_array_1d, &board_array_2d, &added_element };
  if( valid_sequence_of_moves( arr2, 4 ) == true ) cout << "MOVES TO SOLUTION ARE VALID AFTER ADDING" << endl;
  else cout << "they are not valid after adding duplicate" << endl;
  BoardArray1D board_1d2( 5, 5 );
  cout << "Adding new board at the begining" << endl;
  board_1d2.print();
  AbstractBoard* arr3[5] = { &board_1d2, &board_vector, &board_array_1d, &board_array_2d, &added_element };
  if( valid_sequence_of_moves( arr3, 5 ) == true ) cout << "MOVES TO SOLUTION ARE VALID AFTER ADDING" << endl;
  else cout << "they are not valid" << endl;
  AbstractBoard* arr4[2] = { &board_1d2, &board_vector };
  cout << "Puzzles in fourth array" << endl;
  board_1d2.print();
  board_vector.print();
  if( valid_sequence_of_moves( arr4, 2 ) == true ) cout << "MOVES TO SOLUTION ARE VALID AFTER ADDING" << endl;
  else cout << "they are not valid" << endl;

  AbstractBoard* arr5[1] = { &board_1d2 };
  cout << "Fifth array is" << endl;
  board_1d2.print();
  if( valid_sequence_of_moves( arr5, 1 ) == true ) cout << "MOVES TO SOLUTION ARE VALID" << endl;
  else cout << "they are not valid after adding again" << endl;

}
void driverBoardArray1D(){
  BoardArray1D board_array_1d;
  cout << "Newly made board" << endl;
  board_array_1d.print();
  cout << "Executing moves( U, R, L, L, R, D )" << endl;
  board_array_1d.move('U');
  board_array_1d.print();
  board_array_1d.move('R');
  board_array_1d.print();
  board_array_1d.move('L');
  board_array_1d.print();
  board_array_1d.move('L');
  board_array_1d.print();
  board_array_1d.move('R');
  board_array_1d.print();
  board_array_1d.move('D');
  board_array_1d.print();
  cout <<"Writing the board to file named tryout" << endl;
  board_array_1d.writeToFile( "tryout" );

  cout << "Number of moves made before reseting is " << board_array_1d.NumberOfMoves() << endl;
  cout << "Last move made before reseting is " << board_array_1d.lastMove() << endl;
  cout << "Set size( 3,3 ) called it calls reset() inside" << endl;
  board_array_1d.setSize(3,3);
  board_array_1d.print();
  cout << "Number of moves made after reseting is " << board_array_1d.NumberOfMoves() << endl;
  cout << "Checking if it is solved" << endl;
  if( board_array_1d.isSolved() ) cout <<"It is solved"<<endl;
  else cout << "baord is not solved \n";

  cout << "Last move after reseting is:  " << board_array_1d.lastMove() << endl;
  cout << "Number of boards is " << board_array_1d.NumberOfBoards() << endl;
  BoardArray1D board_array_1d_2(3, 3);
  board_array_1d_2(0,0)=0;
  cout << "Number of boards after declaring one new board is " << board_array_1d.NumberOfBoards() << endl;
  cout << "Comparing these two boards " << endl;
  cout << "Board_1: " << endl;
  board_array_1d.print();
  cout << "Board_2: " << endl;
  board_array_1d_2.print();
  cout << "Result of comparison is that they are ";
  if( board_array_1d == board_array_1d_2 ) cout << "equal" << endl;
  else cout << "not equal" << endl;

  cout << "Reading from a file" << endl;
  ifstream my_file;
  my_file.open( "map.txt" );
  board_array_1d.readFromFile( my_file );
  cout << board_array_1d;
  cout << " Making moves ( U, U, R, L, D )" << endl;
  board_array_1d.move('U');
  board_array_1d.print();
  board_array_1d.move('U');
  board_array_1d.print();
  board_array_1d.move('R');
  board_array_1d.print();
  board_array_1d.move('L');
  board_array_1d.print();
  board_array_1d.move('D');
  board_array_1d.print();
  cout <<"At call of row 1 and column 1 (rows and cols start from 0) is: "<< board_array_1d(1,1) << endl;
}
void driverBoardArray2D(){
  BoardArray2D board_array_2d;
  cout << "Newly made board" << endl;
  board_array_2d.print();
  cout << "Executing moves( U, R, L, L, R, D )" << endl;
  board_array_2d.move('U');
  board_array_2d.print();
  board_array_2d.move('R');
  board_array_2d.print();
  board_array_2d.move('L');
  board_array_2d.print();
  board_array_2d.move('L');
  board_array_2d.print();
  board_array_2d.move('R');
  board_array_2d.print();
  board_array_2d.move('D');
  board_array_2d.print();
  cout <<"Writing the board to file named tryout" << endl;
  board_array_2d.writeToFile( "tryout" );

  cout << "Number of moves made before reseting is " << board_array_2d.NumberOfMoves() << endl;
  cout << "Last move made before reseting is " << board_array_2d.lastMove() << endl;
  cout << "Set size( 3,3 ) called it calls reset() inside" << endl;
  board_array_2d.setSize(3,3);
  board_array_2d.print();
  cout << "Number of moves made after reseting is " << board_array_2d.NumberOfMoves() << endl;
  cout << "Checking if it is solved" << endl;
  if( board_array_2d.isSolved() ) cout <<"It is solved"<<endl;
  else cout << "baord is not solved \n";

  cout << "Last move after reseting is:  " << board_array_2d.lastMove() << endl;
  cout << "Number of boards is " << board_array_2d.NumberOfBoards() << endl;
  BoardArray2D board_array_2d_2(4, 3);
  cout << "Number of boards after declaring one new board is " << board_array_2d.NumberOfBoards() << endl;
  cout << "Comparing these two boards " << endl;
  cout << "Board_1: " << endl;
  board_array_2d.print();
  cout << "Board_2: " << endl;
  board_array_2d_2.print();
  cout << "Result of comparison is that they are ";
  if( board_array_2d == board_array_2d_2 ) cout << "equal" << endl;
  else cout << "not equal" << endl;

  cout << "Reading from a file" << endl;
  ifstream my_file;
  my_file.open( "map.txt" );
  board_array_2d.readFromFile( my_file );
  cout << board_array_2d;
  cout << " Making moves ( U, U, R, L, D )" << endl;
  board_array_2d.move('U');
  board_array_2d.print();
  board_array_2d.move('U');
  board_array_2d.print();
  board_array_2d.move('R');
  board_array_2d.print();
  board_array_2d.move('L');
  board_array_2d.print();
  board_array_2d.move('D');
  board_array_2d.print();
  cout <<"At call of row 1 and column 1 (rows and cols start from 0) is: "<< board_array_2d(1,1) << endl;
}
void driverBoardVector(){
  BoardVector board_vect;
  cout << "Newly made board" << endl;
  board_vect.print();
  cout << "Executing moves( U, R, L, L, R, D )" << endl;
  board_vect.move('U');
  board_vect.print();
  board_vect.move('R');
  board_vect.print();
  board_vect.move('L');
  board_vect.print();
  board_vect.move('L');
  board_vect.print();
  board_vect.move('R');
  board_vect.print();
  board_vect.move('D');
  board_vect.print();
  cout <<"Writing the board to file named tryout" << endl;
  board_vect.writeToFile( "tryout" );

  cout << "Number of moves made before reseting is " << board_vect.NumberOfMoves() << endl;
  cout << "Last move made before reseting is " << board_vect.lastMove() << endl;
  cout << "Set size( 3,3 ) called it calls reset() inside" << endl;
  board_vect.setSize(3,3);
  board_vect.print();
  cout << "Number of moves made after reseting is " << board_vect.NumberOfMoves() << endl;
  cout << "Checking if it is solved" << endl;
  if( board_vect.isSolved() ) cout <<"It is solved"<<endl;
  else cout << "baord is not solved \n";

  cout << "Last move after reseting is:  " << board_vect.lastMove() << endl;
  cout << "Number of boards is " << board_vect.NumberOfBoards() << endl;
  BoardVector board_vect_2(4, 3);
  cout << "Number of boards after declaring one new board is " << board_vect.NumberOfBoards() << endl;
  cout << "Comparing these two boards " << endl;
  cout << "Board_1: " << endl;
  board_vect.print();
  cout << "Board_2: " << endl;
  board_vect_2.print();
  cout << "Result of comparison is that they are ";
  if( board_vect == board_vect_2 ) cout << "equal" << endl;
  else cout << "not equal" << endl;

  cout << "Reading from a file" << endl;
  ifstream my_file;
  my_file.open( "map.txt" );
  board_vect.readFromFile( my_file );
  cout << board_vect;
  cout << " Making moves ( U, U, R, L, D )" << endl;
  board_vect.move('U');
  board_vect.print();
  board_vect.move('U');
  board_vect.print();
  board_vect.move('R');
  board_vect.print();
  board_vect.move('L');
  board_vect.print();
  board_vect.move('D');
  board_vect.print();
  cout <<"At call of row 1 and column 1 (rows and cols start from 0) is: "<< board_vect(1,1) << endl;
}
