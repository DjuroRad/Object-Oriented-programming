#include "BoardVector.h"
namespace boardgtu{
BoardVector :: BoardVector( int rows, int cols ):AbstractBoard( rows, cols ){
  allocatePuzzleAndReset();
}
BoardVector :: ~BoardVector(){}//desturctor handled by vector class already, this class does not contain dynamically allocated pointers inside

void BoardVector :: setSize( int cols, int rows ){
    AbstractBoard :: setSize( cols, rows );//this one does the same job for all of the derived calsses

    allocatePuzzleAndReset();//this works the same for every derived class, but purely overloaded allocatePuzzle function called in here works differently for every derived class

    return;
}
void BoardVector :: allocatePuzzle(){//not dynamic directly but is implemented as dynmic inside of the vector class
  puzzle.resize( getRows() );//this function just resizes the vector
  for( int i=0; i < getRows(); ++i)
    puzzle[i].resize( getCols(), (int)EMPTY_CELL );//sets the board to inital value( empty_cell each cell )

  return;
}
int BoardVector :: operator()( int row, int column )const{//this is the same for vector and 2D array but not for the 1D array
  if( row >= 0 && row < getRows() && column >= 0 && column < getCols() )
    return puzzle[ row ][ column ];
  else exit( 1 );//it says we need to terminate a program, i would use exception but since we didn't learn i'll just use exit here
}

int& BoardVector :: operator()( int row, int column ){//used to be able to alter values of puzzle elements from AbstractClass itself
  if( row >= 0 && row < getRows() && column >= 0 && column < getCols() )
    return puzzle[ row ][ column ];
  else exit( 1 );//it says we need to terminate a program, i would use exception but since we didn't learn i'll just use exit here
}

}//end of namespace
