#ifndef ABSTRACTBOARD_H
#define ABSTRACTBOARD_H
#include <iostream>
#include <fstream>
#include <string.h>
#include <cstdlib>
using std :: cout;
using std :: ostream;
using std :: endl;
using std :: cerr;
using std :: cin;
using std :: string;
using std :: ifstream;
using std :: fstream;
using std :: ios;

namespace boardgtu{

class AbstractBoard{
public:
  AbstractBoard( int rows = DEF_ROWS, int columns = DEF_COLS ){ setSize( rows, columns ); ++number_of_boards; }//defaulted to 3, calls setSize of the object's type and than throught that object calls Abstract class's setSize
  virtual ~AbstractBoard(){}//no need to implement anything in here, there are no pointers, but is made virtual to avoid complications since there is an 'is' relationship with the derived class
  virtual void setSize( int rows, int columns );
  void print()const{ cout << *this; }// << operator overloaded
  bool move( char move );
  bool writeToFile( string file_name)const;
  bool readFromFile( ifstream& myfile );
  void reset();
  bool isSolved()const;
  virtual int operator()( int row, int column )const = 0;
  virtual int& operator()( int row, int column ) = 0;//used to avoid code repetition in derived classes
  bool operator == ( const AbstractBoard& rightSide );//check rows and cols first and than precede afterwards
  char lastMove()const { return last_move; };
  int NumberOfMoves() const { return number_of_moves; };
  int NumberOfBoards() const { return number_of_boards; };
  int getCols()const{ return COLUMNS; }
  int getRows()const{ return ROWS; }
  int getEmptyRow()const{ return empty_row; }
  int getEmptyCol()const{ return empty_col; }
  void setEmptyRow( int row ){ empty_row = row; }
  void setEmptyCol( int col ){ empty_col = col; }
  void setNumberOfMoves( int num_of_moves ){ number_of_moves = num_of_moves; }
  void setLastMove( char last_move_new ){ last_move = last_move_new; }
  int getImpossibleMove()const{ return IMPOSSIBLE_MOVE; }
  int getEmptyCellValue()const{ return EMPTY_CELL; }
private:
  virtual void allocatePuzzle() = 0;// every class derived diferently

  int ROWS;
  int COLUMNS;
  static int number_of_boards;//this is the same for all abstract objects, updated inside its constructor

  int empty_col, empty_row;
  char last_move = 'S';
  int number_of_moves = 0;

  friend ostream& operator <<( ostream& output, const AbstractBoard& board_obj );
protected:
  void allocatePuzzleAndReset();
  static int const DEF_ROWS = 3;//defaulted value of rows
  static int const DEF_COLS = 3;//defaulted value of cols
  static const int IMPOSSIBLE_MOVE = 0;
  static const int EMPTY_CELL = -1;
};
bool valid_sequence_of_moves( AbstractBoard* boards[], const int size );//our namespace's global function

}//end of namespace
#endif
