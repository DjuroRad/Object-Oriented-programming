#include "NPuzzle.h"
void NPuzzle :: Board :: reset(){
  for( int i = 0, x = 1; i < ROWS; ++ i ){//x represent the number to be filled in order
    for( int j = 0; j < COLUMNS; ++j ){
      if( puzzle [ i ][ j ] != IMPOSSIBLE_MOVE ){
        puzzle[ i ][ j ] = x;
        ++x;
      }
      else puzzle[ i ][ j ] = puzzle[ i ][ j ];
    }
  }
  empty_row = ROWS - 1;
  empty_col = COLUMNS - 1;
  puzzle[ empty_row ][ empty_col ] = EMPTY_CELL;
  return;
}
void NPuzzle :: Board :: print() const {
    cout << endl; //just one newline for indentation
    for( int i = 0; i < ROWS; i++ ){
      for( int j = 0; j < COLUMNS; j++ ){
        if( puzzle[ i ][ j ] != EMPTY_CELL ) cout << puzzle[ i ][ j ] << "\t";
        else cout << " " << "\t";
      }
      cout << endl << endl << endl << endl << endl;//used for indentation only
    }
}

bool NPuzzle :: Board :: writeToFile( string file_name ) const{
    bool possible = true;

    string number = "00";
    string empty_cell_string = "bb";
    fstream myfile;
    myfile.open( file_name, ios :: out );
    if( !myfile.fail() ){
      for( int i = 0; i < ROWS; ++ i ){
        for( int j = 0; j < COLUMNS; ++ j ){
          if( puzzle[ i ][ j ] != EMPTY_CELL ){
            number[1] = '0' + puzzle[ i ][ j ] % 10;
            number[0] = '0' + puzzle[ i ][ j ] / 10;
            myfile << number;
          }
          else myfile << empty_cell_string;
          myfile << " ";
        }
        myfile << endl;
      }
      myfile.close();
    }
    else possible = false;

    return possible;
}

bool NPuzzle :: Board :: readFromFile( string file_name ){

  string error_message = "Error, could not open the file. Please make sure that the file you want to load your puzzle from exists. ";
  ifstream myfile;
  bool success = false;
  myfile.open( file_name );
  if( !myfile.fail() ){

    string row_of_text;
    int row_count = 0;
    while( getline( myfile, row_of_text ) )//calculating the number of rows in a file
      ++ row_count;

    ROWS = row_count;
    //go back to the beginning of the file to calculate the number of COLUMNS
    myfile.clear();
    myfile.seekg( 0, ios::beg );
    string element;
    int element_count = 0;
    while( myfile >> element)
      ++element_count;

    COLUMNS = element_count / ROWS;
    //again go to the beginning of the file and read element by element
    myfile.clear();
    myfile.seekg( 0, ios :: beg );
    const string impossible_move = "00";
    const string empty_cell = "bb";
    int i = 0, j = 0;
    while( myfile >> element ){
      if( element != empty_cell ){
        if( element != impossible_move)
          puzzle[ i ][ j ] = stoi( element );
        else
          puzzle[ i ][ j ] = IMPOSSIBLE_MOVE;
      }
      else{
        puzzle[ i ][ j ] = EMPTY_CELL;
        empty_row = i;
        empty_col = j;
      }
      ++j;//increment the position
      if( j == COLUMNS ){//update accordingly
        j = 0;
        ++i;
      }
    }
    success = true;
    myfile.close();
    setSolvedPuzzle();//updating our solution puzzle
  }
  else cout << error_message << endl;

  return success;
}


int NPuzzle :: Board :: manhattanDistance() const{
  int manhattan_distance = 0;

  for( int i = 0; i < ROWS; ++i ){
    for( int j = 0; j < COLUMNS; ++j ){
      if( puzzle[ i ][ j ] != EMPTY_CELL && puzzle[ i ][ j ] != IMPOSSIBLE_MOVE )
        manhattan_distance += distanceToGoal( i, j, puzzle[ i ][ j ] );
    }
  }

  return manhattan_distance;
}

int NPuzzle :: Board :: distanceToGoal( int row, int col, int target ) const{
    bool found = false;
    int distance = 0;
    int i,j;
    for( i = 0; i < ROWS && !found ; ++i ){
      for( j = 0; j < COLUMNS && !found; ++j ){
        if( solved_puzzle[ i ][ j ] == target )
          found = true;
      }
    }
    -- i, --j;
    distance = abs( i - row ) + abs( j - col );

    return distance;
}
void NPuzzle :: Board :: setSolvedPuzzle(){

    for( int i = 0, x = 1; i < ROWS; ++ i ){//x represent the number to be filled in order
      for( int j = 0; j < COLUMNS; ++j ){
        if( puzzle [ i ][ j ] != IMPOSSIBLE_MOVE ){
          solved_puzzle[ i ][ j ] = x;
          ++x;
        }
        else solved_puzzle[ i ][ j ] = puzzle[ i ][ j ];
      }
    }
    empty_row_sp = ROWS - 1, empty_col_sp = COLUMNS -1;
    solved_puzzle[ empty_row_sp ][ empty_col_sp ] = EMPTY_CELL;

}
bool NPuzzle :: Board :: move( char move ){
  bool success = false;
  switch( move ){
    case 'R':
    case 'L':
    case 'U':
    case 'D':
      if( moveDirectional( move ) ) success = true;
      break;
    case 'I':
      if( moveDirectional( setIntelligentDirection() ) ) success = true;
      break;
    case 'P':
      if( moveDirectional( setRandomDirection() ) ) success = true;
      break;
  }
  return success;
}
bool NPuzzle :: Board :: moveDirectional( char move ){
  bool success = true;
  int target_row = empty_row, target_col = empty_col;
  setTarget( target_row, target_col, move );
  if( validMove ( target_row, target_col ) ){
    updatePuzzle( target_row, target_col );
    last_move = move;
  }
  else{
    cout << "Inavlid move" << endl;
    success = false;
  }

  return success;
}
void NPuzzle :: Board :: setTarget( int& row, int& col, char move ) const {
    enum dir{ left, right, up, down };//just for accessing the array

    int row_indx = 0, col_indx = 1;
    int direction[ 4 ][ 2 ] = {
      { 0, -1 },//left
      { 0, 1 },//right
      { -1, 0 },//up
      { 1, 0}//down
   };//
   switch ( move ) {
    case 'L':
      row += direction[ left ][ row_indx ];
      col += direction[ left ][ col_indx ];
      break;
    case 'R':
      row += direction[ right ][ row_indx ];
      col += direction[ right ][ col_indx ];
      break;
    case 'U':
      row += direction[ up ][ row_indx ];
      col += direction[ up ][ col_indx ];
      break;
    case 'D':
      row += direction[ down ][ row_indx ];
      col += direction[ down ][ col_indx ];
      break;
   }

   return;
}
bool NPuzzle :: Board :: validMove ( int target_row, int target_col ) const {
    bool valid = false;
    if( target_row >= 0 && target_row < ROWS && target_col >= 0 && target_col < COLUMNS && puzzle[ target_row ][ target_col ] != IMPOSSIBLE_MOVE ) valid = true;

    return valid;
}
void NPuzzle :: Board :: updatePuzzle( int target_row, int target_col ){
  int temp = puzzle [ empty_row ][ empty_col ];
  puzzle [ empty_row ][ empty_col ] = puzzle [ target_row ][ target_col ];
  puzzle [ target_row ][ target_col ] = temp;

  empty_row = target_row;
  empty_col = target_col;
  return;
}

char NPuzzle :: Board :: setIntelligentDirection(){//just branching in four different directions and calculating their distances to final positions separately
  int manh_dist = 0;
  char intelligent_direction = 'N';//still none
  int target_row = empty_row, target_col = empty_col;
  int min = -1;
  //LEFT CHECK
  setTarget( target_row, target_col, 'L' );
  if( validMove ( target_row, target_col ) ){
    updatePuzzle( target_row, target_col );
    min = manh_dist = manhattanDistance();
    intelligent_direction = 'L';
    setTarget( target_row, target_col, 'R' );//going back to the old configuration
    updatePuzzle( target_row, target_col );
  }else setTarget( target_row, target_col, 'R' );
  //RIGHT CHECK
  setTarget( target_row, target_col, 'R' );
  if( validMove ( target_row, target_col ) ){
    updatePuzzle( target_row, target_col );
    manh_dist = manhattanDistance();
    if( min > manh_dist || min == -1 ){
      min = manh_dist;
      intelligent_direction = 'R';
    }
    setTarget( target_row, target_col, 'L' );//going back to the old configuration
    updatePuzzle( target_row, target_col );
  }else setTarget( target_row, target_col, 'L' );
  //UP CHECK
  setTarget( target_row, target_col, 'U' );
  if( validMove ( target_row, target_col ) ){
    updatePuzzle( target_row, target_col );
    manh_dist = manhattanDistance();
    if( min > manh_dist || min == -1 ){
      min = manh_dist;
      intelligent_direction = 'U';
    }
    setTarget( target_row, target_col, 'D' );//going back to the old configuration
    updatePuzzle( target_row, target_col );
  }else setTarget( target_row, target_col, 'D' );
  //DOWN CHECK
  setTarget( target_row, target_col, 'D' );
  if( validMove ( target_row, target_col ) ){
    updatePuzzle( target_row, target_col );
    manh_dist = manhattanDistance();
    if( min > manh_dist || min == -1 ){
      min = manh_dist;
      intelligent_direction = 'D';
    }
    setTarget( target_row, target_col, 'U' );//going back to the old configuration
    updatePuzzle( target_row, target_col );
  }else setTarget( target_row, target_col, 'U' );

  return intelligent_direction;
}

char NPuzzle :: Board :: setRandomDirection() const{
  char rand_direction = 'N';
  const int NUM_OF_DIRECTIONS = 4;
  int rand_num = rand() % NUM_OF_DIRECTIONS;// down up left intelligent_to_right
  int target_row = empty_row, target_col = empty_col;
  rand_direction = directionItoChar( rand_num );

  setTarget( target_row, target_col, rand_direction );
  if( !validMove( target_row, target_col ) ){
      do{
        target_row = empty_row, target_col = empty_col;
        rand_num = ( rand_num + 1 ) % NUM_OF_DIRECTIONS;
        rand_direction = directionItoChar( rand_num );
        setTarget( target_row, target_col, rand_direction );
    }while( !validMove( target_row, target_col ) );//won't go into infinite loop since there must exist a valid position
  }
  return rand_direction;
}
char NPuzzle :: Board :: directionItoChar( int num ) const {
  char rand_direction = 'N';
  switch( num ){
    case 0://left
      rand_direction = 'L';
      break;
    case 1://right
      rand_direction = 'R';
      break;
    case 2://up
      rand_direction = 'U';
      break;
    case 3://down
      rand_direction = 'D';
      break;
  }

  return rand_direction;
}
