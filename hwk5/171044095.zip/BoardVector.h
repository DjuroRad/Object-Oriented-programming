#ifndef BOARDVECTOR_H
#define BOARDVECTOR_H
#include "AbstractBoard.h"
#include <vector>
using std :: vector;
namespace boardgtu{

class BoardVector : public AbstractBoard{
public:
  BoardVector( int rows = DEF_ROWS, int cols = DEF_COLS );
  ~BoardVector();
  void setSize( int rows, int columns ) override;
  int operator()( int row, int column )const override final;
  int& operator()( int row, int column ) override final;

private:
  void allocatePuzzle() override final;
  vector< vector<int> > puzzle;
};

}//end of namespace
#endif
