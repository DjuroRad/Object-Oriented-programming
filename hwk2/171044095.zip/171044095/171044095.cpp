#include <iostream>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <string>
#include <limits>
#define EMPTY_CELL -1
#define IMPOSSIBLE_MOVE 0
// #define DEBUGG
using namespace std;

typedef struct Puzzle{
  int** puzzle;
  int empty_row;
  int empty_col;
  int ROWS;
  int COLUMNS;
  bool read_from_file;
}Puzzle;

typedef enum{ d, u, l, r, none, s, q, i, T, L, V, E } input;//d - down, u - up, l - left, r - right, q - quit, i - intelligent move

string getFileNameFromUser();// If user types in multiple words only the first one will be considered
bool validPosition( int** puzzle, int row, int col, int ROWS, int COLUMNS );
int** setSize( int* COLUMNS, int* ROWS );
void setSolvablePuzzle( int** puzzle, int ROWS, int COLUMNS, int* empty_row, int* empty_col );
int calculateInversions( int** puzzle, int ROWS, int COLUMNS );
bool isSolvablePuzzle( int** puzzle, int ROWS, int COLUMNS, int empty_row );
void changePuzzleSolvability( int** puzzlle, int ROWS, int COLUMNS, int empty_row );
void swapRandomPair( int** puzzle, int ROWS, int COLUMNS );
int manhattanDistance( int** puzzle, int ROWS, int COLUMNS );
int distanceToGoal(int row, int col, int num, int ROWS, int COLUMNS );
bool isValidNum( char c, int MIN );
void printPuzzle( int** puzzle, int ROWS, int COLUMNS );
void emptyOutPuzzle( int** puzzle, int ROWS, int COLUMNS );
void updatePuzzle( int* empty_row, int* empty_col, int new_row, int new_col, int** puzzle );
void updatePuzzle( int* empty_row, int* empty_col, input move, int** puzzle );
input setIntelligentMove( int** puzzle, int ROWS, int COLUMNS, int* empty_row, int* empty_col );
bool makeMove( int**& puzzle, int& ROWS, int& COLUMNS, int* empty_row, int* empty_col, int* move_count );
bool makeMove( input move, int**& puzzle, int& ROWS, int& COLUMNS, int* empty_row, int* empty_col, int* move_count );
input getMoveFromUser();
bool writePuzzleToFile( int** puzzle, int ROWS, int COLUMNS );
bool readPuzzleFromFile( int**& puzzle, int& ROWS, int& COLUMNS, int* empty_row, int* empty_col );
bool processFile( string file_name, int**& puzzle, int& ROWS, int& COLUMNS, int* empty_row, int* empty_col );
string getFileNameFromARGV( char** argv );
bool modifyTargetPositionByDirection( input direction, int& target_row, int& target_col );
input makeRandomMove( int** puzzle, int ROWS, int COLUMNS, int& empty_row, int& empty_col );
input setRandomDirection( int** puzzle, int ROWS, int COLUMNS, int empty_row, int empty_col );
// void getValidRandomDirection( int** puzzle, input& direction, int ROWS, int COLUMNS, int empty_row, int empty_col, int iter, int max_iter ){//we know that there is at least one possible random direction, so just search for it recursively until it is found
void sufflePuzzle( int**& puzzle, int ROWS, int COLUMNS, int& empty_row, int& empty_col );
int** make2dArrayDyn( int ROWS, int COLUMNS );
int** makeSolvedPuzzle( int** puzzle, int ROWS, int COLUMNS, int& empty_row_sp, int& empty_col_sp );
int distanceToGoal( int row, int col, int target, int** solved_puzzle, int ROWS, int COLUMNS );
input getInvMove( input move );
void solvePuzzle( int** puzzle, int ROWS, int COLUMNS, int& empty_row, int& empty_col, int& move_count );
inline void printIntelligentMoveInfo( input intelligent_move );
inline void printComputerMoveInfo( input move );

int main( int argc, char** argv ){
  srand( time( NULL ) );//for generating different random numbers every time

  int count = 0;
  int COLUMNS = 0, ROWS = 0;
  int** puzzle = NULL;//sets the size of the puzzle according to user input
  int empty_row = 0, empty_col = 0;
  bool quit = false;
  string user_notification = "Exiting ...";
  string user_notification2 = "Your initial random board is: ";
  string user_move_notification = "Your move :";
  string user_success = "Problem Solved!";
  string number_of_moves = "Total number of moves ";
  string file_name;
  if( argc > 1 ){
    file_name = getFileNameFromARGV( argv );
    if( !processFile( file_name, puzzle, ROWS, COLUMNS, &empty_row, &empty_col ) ){
      puzzle = setSize( &COLUMNS, &ROWS );
      setSolvablePuzzle( puzzle, ROWS, COLUMNS, &empty_row, &empty_col );
    }
  }
  else{
    puzzle = setSize( &COLUMNS, &ROWS );
    setSolvablePuzzle( puzzle, ROWS, COLUMNS, &empty_row, &empty_col );
  }
  // readPuzzleFromFile( puzzle, ROWS, COLUMNS, empty_row, empty_col );

  //Game loop in here
  cout << user_notification2 << endl;
  printPuzzle( puzzle, ROWS, COLUMNS );

  while( !quit ){
    cout << user_move_notification;
    if( !makeMove( puzzle, ROWS, COLUMNS, &empty_row, &empty_col, &count ) ){//make move returns false on quitting the game
      cout << number_of_moves << count << endl;
      cout << user_notification << endl;
      quit = true;
    }
    #ifdef DEBUG
    cout << "MANHATTAN DISTANCE IS " <<  manhattanDistance( puzzle, ROWS, COLUMNS ) << endl;
    #endif
    if( manhattanDistance( puzzle, ROWS, COLUMNS ) == 0 ){//checks if user finished the game. At this point every tile will be at its own position which would mean user succesfully finished the game
      cout << user_success << endl;
      cout << number_of_moves << count << endl;
      quit = true;
    }
    else if( !quit )
      printPuzzle( puzzle, ROWS, COLUMNS );


  }
  emptyOutPuzzle( puzzle, ROWS, COLUMNS );//freeing memory reserved for our puzzle
}

string getFileNameFromARGV( char** argv ){
  string file_name;
  int file_name_index = 1;//being the second argument since the first one is .o file
  file_name = argv[ file_name_index ];
  return file_name;
}
int** setSize( int* COLUMNS, int* ROWS ){
  int** puzzle = NULL;
  const int MIN = 3;//Minimum input
  const int CORRECT_INPUT_LENGTH = 1;
  *ROWS = *COLUMNS = 0;
  string input;//taking the whole line from the user so that I could manipulate the user input if there are errors
  string error_message = "Please only include 1 integer digit bigger than 2 ( 3, 4, 5 ... 9 ) in your input";
  string question_for_user = "Please enter the problem size";
  do{
    cout << question_for_user << endl;
    getline( cin, input );
    if( isValidNum( input[0], MIN ) && input.length() == CORRECT_INPUT_LENGTH ){//Allocating memory upon a valid input
      *ROWS = *COLUMNS = input[0] - '0';
      puzzle = ( int** )malloc( ( *ROWS ) * sizeof( int* ) );
      for( int i = 0; i < *ROWS; i++ ) puzzle[i] = ( int* )malloc( ( *COLUMNS ) * sizeof( int ) );
    }
    else cerr << error_message << endl;
  }while( *ROWS == 0 );//min input is 3 so rows can't be 0


  return puzzle;
}
//this function is also used for suffling
void setSolvablePuzzle( int** puzzle, int ROWS, int COLUMNS, int* empty_row, int* empty_col ){//making already allocated puzzle solvable
  //making ordered puzzle( with final positions )
  for( int i = 0, num = 1; i < ROWS; i++ ){
    for( int j = 0; j < COLUMNS; j++, num++ ) puzzle[ i ][ j ] = num;
  }
  puzzle[ ROWS - 1 ][ COLUMNS - 1 ] = EMPTY_CELL;

  //shuffling the array ROWS*COLUMNS times
  for( int i = 0; i < ROWS*COLUMNS; i++ )
    swapRandomPair( puzzle, ROWS, COLUMNS );//this function swaps two pair values in the puzzle randomly
  // setting the empty row and the empty column
  *empty_row = -1;
  for( int i = 0; i < ROWS && *empty_row == -1 ; i++ ){//find the empty row so that we could set its position
    for( int j = 0; j < COLUMNS; j++ ){
      if( puzzle[ i ][ j ] == EMPTY_CELL ){
        *empty_row = i;
        *empty_col = j;
        break;
      }
    }
  }
  //making it solvable, by changing the number of inversions
  if( !isSolvablePuzzle( puzzle, ROWS, COLUMNS, *empty_row ) )
    changePuzzleSolvability( puzzle, ROWS, COLUMNS, *empty_row );
  //making the puzzle not solved if it already is so by accident after doing this
  if( manhattanDistance( puzzle, ROWS, COLUMNS ) == 0 ){
    //moving the empty_cell randomly backwards for more than 1 move
    int rand_row = rand() % ROWS;
    int rand_col = rand() % COLUMNS;
    if( rand_row == ROWS - 1 && rand_col == COLUMNS - 1 ) -- rand_row;// since empty cell's row has to be max row position when solved it means we can go backwards without checking if that empty cell's value is 0( minimum is 2 and that is for 3x3 puzzle )
    int temp = puzzle[ rand_row ][ rand_col ];
    puzzle[ rand_row ][ rand_col ] = puzzle[ *empty_row ][ *empty_col ];
    puzzle[ *empty_row ][ *empty_row ] = temp;
    *empty_row = rand_row;
    *empty_col = rand_col;
  }

  return;
}

void swapRandomPair( int** puzzle, int ROWS, int COLUMNS ){
  int rand_row = rand() % ROWS;
  int rand_col = rand() % COLUMNS;
  int rand_row2 = rand() % ROWS;
  int rand_col2 = rand() % COLUMNS;
  int temp = puzzle[ rand_row ][ rand_col ];
  puzzle[ rand_row ][ rand_col ] =  puzzle[ rand_row2 ][ rand_col2 ];
  puzzle[ rand_row2 ][ rand_col2 ] = temp;

  return;
}
//makePuzzleSolvable is acutally changing sol
void changePuzzleSolvability( int** puzzle, int ROWS, int COLUMNS, int empty_row ){//swaping place of two numbers inside the puzzle so that its inversions are altered so that it is made solvable
  int rand_row = rand() % ROWS;
  int rand_col = rand() % COLUMNS;
  int temp = 0;
  if( rand_row == empty_row ){//changing the place with the empty cell won't change parity of the number of inversions
    if( rand_row < ROWS - 1 ) rand_row ++;
    else rand_row --;
  }
  if( rand_col == COLUMNS - 1 ) rand_col --;
  temp = puzzle[ rand_row ][ rand_col ];
  puzzle[ rand_row ][ rand_col ] = puzzle[ rand_row ][ rand_col + 1 ];
  puzzle[ rand_row ][ rand_col + 1 ] = temp;

  return;
}

bool isSolvablePuzzle( int** puzzle, int ROWS, int COLUMNS, int empty_row ){
  bool solvable = false;
  int num_of_inversions = calculateInversions( puzzle, ROWS, COLUMNS );
  if( COLUMNS % 2 != 0 && num_of_inversions % 2 == 0 ) solvable = true;
  else if( COLUMNS % 2 == 0 ){
    if( num_of_inversions % 2 != 0 && empty_row % 2 == 0 ) solvable = true;
    if( num_of_inversions % 2 == 0 && empty_row % 2 != 0 ) solvable = true;
  }

  return solvable;
}

int calculateInversions( int** puzzle, int ROWS, int COLUMNS ){
  int num_of_inversions = 0;
  const int total_elements = ROWS * COLUMNS - 1;
  int puzzle_1d[ total_elements ];

  for( int i = 0, i_1d = 0; i < ROWS; i++ ){//setting the 1d array from which the num of inversions would be calculated
    for( int j=0; j < COLUMNS; j++, i_1d++ ){
      if( puzzle[ i ][ j ] != EMPTY_CELL ) puzzle_1d[ i_1d ] = puzzle[ i ][ j ];
      else i_1d--;
    }
  }

  for( int i = 0; i < total_elements - 1; ++ i ){//calculating the number of inversions
    for( int j = i + 1; j < total_elements; ++ j ){
      if( puzzle_1d[ i ] > puzzle_1d[ j ] ) ++ num_of_inversions;
    }
  }

  return num_of_inversions;
}

bool isValidNum( char c, int MIN ){
  bool res = false;
  char min = MIN + '0';
  if( c >= min && c <= '9') res = true;// >= '3' since our minimum puzzle board will be 3x3

  return res;
}

void printPuzzle( int** puzzle, int ROWS, int COLUMNS ){
  cout << endl; //just one newline for indentation
  for( int i = 0; i < ROWS; i++ ){
    for( int j = 0; j < COLUMNS; j++ ){
      if( puzzle [ i ][ j ] != EMPTY_CELL ) cout << puzzle[ i ][ j ] << "\t";
      else cout << " " << "\t";
    }
    cout << endl << endl << endl << endl << endl;//used for indentation only
  }
}

int manhattanDistance( int** puzzle, int ROWS, int COLUMNS ){
  int manhattan_distance = 0;
  // // calculating manhattan distance
  // THIS CODE WAS PREVIOUSLY USED TO CALCULATE MANHATTAN DISTANCE
  // for( int i = 0; i < ROWS; ++i ){
  //   for( int j = 0; j < COLUMNS; ++j ){
  //     if( puzzle[ i ][ j ] != EMPTY_CELL ) manhattan_distance += distanceToGoal( i, j, puzzle[ i ][ j ], ROWS, COLUMNS );
  //   }
  // }

  //calculating manhattan distance if we know this is not the case ( 3*3 with no impossible moves )
  manhattan_distance = 0;
  int empty_col_sp = 0, empty_row_sp = 0;
  int** solved_puzzle = makeSolvedPuzzle( puzzle, ROWS, COLUMNS, empty_row_sp, empty_col_sp );
  for( int i = 0; i < ROWS; ++i ){
    for( int j = 0; j < COLUMNS; ++j ){
      if( puzzle[ i ][ j ] != EMPTY_CELL && puzzle[ i ][ j ] != IMPOSSIBLE_MOVE )
        manhattan_distance += distanceToGoal( i, j, puzzle[ i ][ j ], solved_puzzle, ROWS, COLUMNS );
    }
  }

  emptyOutPuzzle( solved_puzzle, ROWS, COLUMNS );
  return manhattan_distance;
}
int distanceToGoal( int row, int col, int target, int** solved_puzzle, int ROWS, int COLUMNS ){
  bool found = false;
  int distance = 0;
  int i,j;
  for( i = 0; i < ROWS && !found ; ++i ){
    for( j = 0; j < COLUMNS && !found; ++j ){
      if( solved_puzzle[ i ][ j ] == target )
        found = true;
    }
  }
  -- i, --j;
  distance = abs( i - row ) + abs( j - col );

  return distance;
}
int distanceToGoal(int row, int col, int num, int ROWS, int COLUMNS ){//this can be done like this because we know the puzzle is ordered
  int distance = 0, row_goal = 0, col_goal = 0, row_diffrence = 0, col_diffrence  = 0;
  int i = 0;
  while( num > COLUMNS * ( i + 1 ) ) ++i;
  row_goal = i;
  col_goal = num - ( COLUMNS * i + 1 ) ;
  row_diffrence = row_goal - row;
  col_diffrence = col_goal - col;
  if( row_diffrence < 0 ) row_diffrence *= -1;
  if( col_diffrence < 0 ) col_diffrence *= -1;
  distance += row_diffrence + col_diffrence;

  return distance;
}

void emptyOutPuzzle( int** puzzle, int ROWS, int COLUMNS ){
    for( int i = 0; i < ROWS; ++i ) free( puzzle[ i ] );
    free( puzzle );

    return;
}

bool validPosition( int** puzzle, int row, int col, int ROWS, int COLUMNS ){
  bool valid = false;
  if( row >= 0 && row < ROWS && col >= 0 && col < COLUMNS && puzzle[ row ][ col ] != IMPOSSIBLE_MOVE ) valid = true;

  return valid;
}

inline void printIntelligentMoveInfo( input intelligent_move ){
  string intelligent_to_right = "Intelligent move choses r";
  string intelligent_to_left = "Intelligent move choses l";
  string intelligent_to_down = "Intelligent move choses d";
  string intelligent_to_up = "Intelligent move choses u";

  switch ( intelligent_move ) {
    case r:
     cout << intelligent_to_right << endl;
     break;
    case l:
      cout << intelligent_to_left << endl;
      break;
    case u:
     cout << intelligent_to_up << endl;
     break;
    case d:
      cout << intelligent_to_down << endl;
      break;
  }
}

input setIntelligentMove( int** puzzle, int ROWS, int COLUMNS, int* empty_row, int* empty_col ){//just branching in four different directions and calculating their distances to final positions separately
  int manh_dist_r = 0, manh_dist_l = 0, manh_dist_u = 0, manh_dist_d = 0;//4 different variables just for readability purposes
  input new_direction = none;

  int min = -1;
  if( validPosition( puzzle, *empty_row, *empty_col + 1, ROWS, COLUMNS ) ){//manh dist for the move to the right
    updatePuzzle( empty_row, empty_col, *empty_row, *empty_col + 1, puzzle );
    manh_dist_r = manhattanDistance( puzzle, ROWS, COLUMNS );
    min = manh_dist_r;
    new_direction = r;
    updatePuzzle( empty_row, empty_col, *empty_row, *empty_col - 1, puzzle );
  }
  if( validPosition( puzzle, *empty_row, *empty_col - 1, ROWS, COLUMNS ) ){//manh dist for the move to the left
    updatePuzzle( empty_row, empty_col, *empty_row, *empty_col - 1, puzzle );
    manh_dist_l = manhattanDistance( puzzle, ROWS, COLUMNS );
    if( min > manh_dist_l || min == - 1 ){
      min = manh_dist_l;
      new_direction = l;
    }
    updatePuzzle( empty_row, empty_col, *empty_row, *empty_col + 1, puzzle );
  }
  if( validPosition( puzzle, *empty_row + 1, *empty_col, ROWS, COLUMNS ) ){//manh dist for the move down
    updatePuzzle( empty_row, empty_col, *empty_row + 1, *empty_col, puzzle );
    manh_dist_d = manhattanDistance( puzzle, ROWS, COLUMNS );
    if( min > manh_dist_d || min == -1){
      min = manh_dist_d;
      new_direction = d;
    }
    updatePuzzle( empty_row, empty_col, *empty_row - 1, *empty_col, puzzle );
  }
  if( validPosition( puzzle, *empty_row - 1, *empty_col, ROWS, COLUMNS ) ){//manh dist for the move up
    updatePuzzle( empty_row, empty_col, *empty_row - 1, *empty_col, puzzle );
    manh_dist_u = manhattanDistance( puzzle, ROWS, COLUMNS );
    if( min > manh_dist_u || min == -1){
      min = manh_dist_u;
      new_direction = u;
    }
    updatePuzzle( empty_row, empty_col, *empty_row + 1, *empty_col, puzzle );
  }

  return new_direction;
}
void updatePuzzle( int* empty_row, int* empty_col, int new_row, int new_col, int** puzzle ){
  int temp = puzzle[ *empty_row ][ *empty_col ];
  puzzle[ *empty_row ][ *empty_col ] = puzzle[ new_row ][ new_col ];
  puzzle[ new_row ][ new_col ] = temp;
  *empty_row = new_row;
  *empty_col = new_col;
  return;
}
void updatePuzzle( int* empty_row, int* empty_col, input move, int** puzzle ){// move passed to this function can be only u d l f ( directional )
  // directional move passed to this function needs to be checked for validity beforehand, otherwise it can give seg fault or an error
  int new_row = *empty_row;
  int new_col = *empty_col;
  switch ( move ) {
    case u:
      -- new_row;
      break;
    case d:
      ++ new_row;
      break;
    case l:
      -- new_col;
      break;
    case r:
      ++ new_col;
      break;
  }
  int temp = puzzle[ *empty_row ][ *empty_col ];
  puzzle[ *empty_row ][ *empty_col ] = puzzle[ new_row ][ new_col ];
  puzzle[ new_row ][ new_col ] = temp;
  *empty_row = new_row;
  *empty_col = new_col;
  return;
}

bool makeMove( int**& puzzle, int& ROWS, int& COLUMNS, int* empty_row, int* empty_col, int* move_count ){
  bool valid_move = true;
  input move = getMoveFromUser();
  valid_move = makeMove( move, puzzle, ROWS, COLUMNS, empty_row, empty_col, move_count);

  return valid_move;
}

bool makeMove( input move, int**& puzzle, int& ROWS, int& COLUMNS, int* empty_row, int* empty_col, int* move_count ){
  string error_message = "Error. Chosen move is not possible.";
  bool valid_move = true;
  int target_row = *empty_row, target_col = *empty_col;

  if( move == i ){
    move = setIntelligentMove( puzzle, ROWS, COLUMNS, empty_row, empty_col );//sets the direction of the inteligent move
    printIntelligentMoveInfo( move );
  }
  switch ( move ) {
    case u:
      -- target_row;
      break;
    case d:
      ++ target_row;
      break;
    case l:
      -- target_col;
      break;
    case r:
      ++ target_col;
      break;
    case s:
      sufflePuzzle( puzzle, ROWS, COLUMNS, *empty_row, *empty_col );
      *move_count = 0;
      cout << "Your new puzzle: " << endl;
      break;
    case T:
      cout << "Number of moves that have been done: " << *move_count << endl;
      if( manhattanDistance( puzzle, ROWS, COLUMNS ) == 0 /*&& notReadFromFile*/) cout << "Solution is found" << endl;
      else cout << "Solution is not found" << endl;
    break;
    case L:
      if( readPuzzleFromFile( puzzle, ROWS, COLUMNS, empty_row, empty_col ) )
        *move_count = 0;
      target_row = *empty_row;
      target_col = *empty_col;//avoding error message
      break;
    case V:
      solvePuzzle( puzzle, ROWS, COLUMNS, *empty_row, *empty_col, *move_count );
      break;
    case E:
      writePuzzleToFile( puzzle, ROWS, COLUMNS );
      break;
    case q:
      valid_move = false;
      break;
  }
  if( validPosition( puzzle, target_row, target_col, ROWS, COLUMNS ) ){
    if( move == l || move == r || move == u || move == d ){
      updatePuzzle( empty_row, empty_col, target_row, target_col, puzzle );
      ++(*move_count);
    }
  }
  else{
    cerr << error_message << endl;
  }

  return valid_move;
}

input getMoveFromUser(){

  input user_move = none;
  const int input_size = 1;
  string input;

  string error_message = "Error: Invalid input. Input examples: 'l', 'L', 'r', 'R', 'u', 'U', 'd', 'D'. Please try again: ";
  while( user_move == none ){
    getline( cin, input );
    if( input.length() == input_size ){
      switch ( input[0] ) {
        case 'l':
        case 'L':
          user_move = l;
          break;
        case 'r':
        case 'R':
          user_move = r;
          break;
        case 'u':
        case 'U':
          user_move = u;
          break;
        case 'd':
        case 'D':
          user_move = d;
          break;
        case 's':
          user_move = s;
          break;
        case 'q':
          user_move = q;
          break;
        case 'i':
          user_move = i;
          break;
        case 'T':
          user_move = T;
          break;
        case 'Y':
          user_move = L;
          break;
        case 'V':
          user_move = V;
          break;
        case 'E':
          user_move = E;
          break;
      }
    }
    if( user_move == none ) cerr << error_message << endl;

  }

  return user_move;
}
bool processFile( string file_name, int**& puzzle, int& ROWS, int& COLUMNS, int* empty_row, int* empty_col ){
  string error_message = "Error, could not open the file. Please make sure that the file you want to load your puzzle from exists. ";
  ifstream myfile;
  bool success = false;
  myfile.open( file_name );
  if( !myfile.fail() ){
    //deallocate the old puzzle
    emptyOutPuzzle( puzzle, ROWS, COLUMNS );

    string row_of_text;
    int row_count = 0;
    while( getline( myfile, row_of_text ) )//calculating the number of rows in a file
      ++ row_count;

    ROWS = row_count;

    //go back to the beginning of the file to calculate the number of COLUMNS
    myfile.clear();
    myfile.seekg( 0, ios::beg );
    string element;
    int element_count = 0;
    while( myfile >> element)
      ++element_count;

    COLUMNS = element_count / ROWS;
    //get memory for the new puzzle
    puzzle = NULL;
    puzzle = ( int** )malloc( ROWS * sizeof( int* ) );
    for( int i = 0; i < ROWS; ++ i )
      puzzle[ i ] = ( int* )malloc( COLUMNS * sizeof( int ) );
    //go back to the beginning of the file once again
    myfile.clear();
    myfile.seekg( 0, ios :: beg );
    const string impossible_move = "00";
    const string empty_cell = "bb";
    int i = 0, j = 0;
    while( myfile >> element ){
      if( element != empty_cell ){
        if( element != impossible_move)
          puzzle[ i ][ j ] = stoi( element );
        else
          puzzle[ i ][ j ] = IMPOSSIBLE_MOVE;
      }
      else{
        puzzle[ i ][ j ] = EMPTY_CELL;
        *empty_row = i;
        *empty_col = j;
      }
      ++j;//increment the position
      if( j == COLUMNS ){//update accordingly
        j = 0;
        ++i;
      }
    }
    success = true;
    myfile.close();
  }
  else cout << error_message << endl;
  return success;
}
string getFileNameFromUser(){// If user types in multiple words only the first one will be considered
  string info = "Please enter the name of your file ( Note that if you input your file name with spaces only the first word will be taken as file name ): ";
  cout << info;
  string line;
  string file_name;
  getline( cin, line );
  size_t i = line.find_first_of( ' ' );
  file_name = line.substr( 0, i );

  return file_name;
}
bool readPuzzleFromFile( int**& puzzle, int& ROWS, int& COLUMNS, int* empty_row, int* empty_col ){
    bool success = false;
    string file_name = getFileNameFromUser();

    success = processFile( file_name, puzzle, ROWS, COLUMNS, empty_row, empty_col );

    return success;
}
bool writePuzzleToFile( int** puzzle, int ROWS, int COLUMNS ){
  bool possible = true;
  string file_name = getFileNameFromUser();

  string number = "00";
  string empty_cell_string = "bb";
  fstream myfile;
  myfile.open( file_name, ios :: out );
  if( !myfile.fail() ){
    for( int i = 0; i < ROWS; ++ i ){
      for( int j = 0; j < COLUMNS; ++ j ){
        if( puzzle[ i ][ j ] != EMPTY_CELL ){
          number[1] = '0' + puzzle[ i ][ j ] % 10;
          number[0] = '0' + puzzle[ i ][ j ] / 10;
          myfile << number;
        }
        else myfile << empty_cell_string;
        myfile << " ";
      }
      myfile << endl;
    }
    myfile.close();
  }
  else possible = false;

  return possible;
}

void getValidRandomDirection( int** puzzle, input& direction, int ROWS, int COLUMNS, int empty_row, int empty_col, int iter, int max_iter ){//we know that there is at least one possible random direction, so just search for it recursively until it is found
  switch ( direction ) {
    case d:
      if( validPosition( puzzle, empty_row + 1, empty_col, ROWS, COLUMNS ) )
        iter = max_iter;//break the loop
      else direction = u;
      break;
    case u:
      if( validPosition( puzzle, empty_row - 1, empty_col, ROWS, COLUMNS ) )
        iter = max_iter;//break the loop
      else direction = l;
      break;
    case l:
      if( validPosition( puzzle, empty_row, empty_col - 1, ROWS, COLUMNS ) )
        iter = max_iter;//break the loop
      else direction = r;
      break;
    case r:
      if( validPosition( puzzle, empty_row, empty_col + 1, ROWS, COLUMNS ) )
        iter = max_iter;//break the loop
      else direction = d;
      break;
  }
  if( iter != max_iter ) getValidRandomDirection( puzzle, direction, ROWS, COLUMNS, empty_row, empty_col, iter, max_iter );//we know that there is at least one possible random direction, so just search for it recursively until it is found
  else return;//function's return value modified by reference
}

input setRandomDirection( int** puzzle, int ROWS, int COLUMNS, int empty_row, int empty_col ){// sets random valid direction for the given puzzle
  input rand_direction = d;
  const int NUM_OF_DIRECTIONS = 4;
  int rand_num = rand() % NUM_OF_DIRECTIONS;// down up left intelligent_to_right

  switch( rand_num ){
    case 0://down
      rand_direction = d;
      break;
    case 1://up
      rand_direction = u;
      break;
    case 2://left
      rand_direction = l;
      break;
    case 3://right
      rand_direction = r;
      break;
  }
  getValidRandomDirection( puzzle, rand_direction, ROWS, COLUMNS, empty_row, empty_col, 1, NUM_OF_DIRECTIONS );//we know that there is at least one possible random direction, so just search for it recursively until it is found

  return rand_direction;
}

bool modifyTargetPositionByDirection( input direction, int& target_row, int& target_col ){
  bool success = true;

  switch ( direction ) {
    case d:
      ++ target_row;
      break;
    case u:
      -- target_row;
      break;
    case r:
      ++ target_col;
      break;
    case l:
      -- target_col;
      break;
    default:
      success = false;
  }

  return success;
}

input makeRandomMove( int** puzzle, int ROWS, int COLUMNS, int& empty_row, int& empty_col ){
  auto direction = d;// d is the first defined enum type

  direction = setRandomDirection( puzzle, ROWS, COLUMNS, empty_row, empty_col );

  int target_row = empty_row;
  int target_col = empty_col;
  modifyTargetPositionByDirection( direction, target_row, target_col );//function made just for readability purposes
  updatePuzzle( &empty_row, &empty_col, target_row, target_col, puzzle );//update the empty row and empty columns also!
  #ifdef DEBUG
    switch( direction ){
      case d:
        cout << "DOWN RANDOM MOVE" << endl;
        break;
      case u:
        cout << "UP RANDOM MOVE" << endl;
        break;
      case l:
        cout << "LEFT RANDOM MOVE" << endl;
        break;
      case r:
        cout << "RIGHT RANDOM MOVE" << endl;
        break;
    }
    printPuzzle( puzzle, ROWS, COLUMNS );
  #endif

  return direction;
}

int** make2dArrayDyn( int ROWS, int COLUMNS ){

  int** array = ( int** )malloc( ROWS*sizeof( int* ) );
  for( int i = 0; i < ROWS; ++i ){
    array[ i ] = ( int* )malloc( COLUMNS*sizeof( int ) );
  }

  return array;
}

int** makeSolvedPuzzle( int** puzzle, int ROWS, int COLUMNS, int& empty_row_sp, int& empty_col_sp ){
  int** solvedPuzzle = make2dArrayDyn( ROWS, COLUMNS );

  for( int i = 0, x = 1; i < ROWS; ++ i ){//x represent the number to be filled in order
    for( int j = 0; j < COLUMNS; ++j ){
      if( puzzle [ i ][ j ] != IMPOSSIBLE_MOVE ){
        solvedPuzzle[ i ][ j ] = x;
        ++x;
      }
      else solvedPuzzle[ i ][ j ] = puzzle[ i ][ j ];
    }
  }
  empty_row_sp = ROWS - 1, empty_col_sp = COLUMNS -1;
  solvedPuzzle[ empty_row_sp ][ empty_col_sp ] = EMPTY_CELL;

  return solvedPuzzle;
}

void sufflePuzzle( int**& puzzle, int ROWS, int COLUMNS, int& empty_row, int& empty_col ){

  int** solvedPuzzle = NULL;
  int empty_row_sp = ROWS - 1, empty_col_sp = COLUMNS -1;//down right position
  solvedPuzzle = makeSolvedPuzzle( puzzle, ROWS, COLUMNS, empty_row_sp, empty_col_sp );

  #ifdef DEBUG
  cout << "SOLVED PUZZLE IS" << endl;
  printPuzzle( solvedPuzzle, ROWS, COLUMNS );
  #endif

  int max = ROWS*COLUMNS;
  for( int i = 0; i < max; ++i )//making ROWS*COLUMNS random moves since for puzzles read from a file that have random shapes we can't easily solve the solvability problem with inversions like we did for the puzzles where there are no impossible moves and are square
  makeRandomMove( solvedPuzzle, ROWS, COLUMNS, empty_row_sp, empty_col_sp );
  if( manhattanDistance( puzzle, ROWS, COLUMNS ) == 0 )
    makeRandomMove( solvedPuzzle, ROWS, COLUMNS, empty_row_sp, empty_col_sp );
  emptyOutPuzzle( puzzle, ROWS, COLUMNS );//emptying out the previous configuration to avoid zombie allocation
  empty_row = empty_row_sp;
  empty_col = empty_col_sp;
  puzzle = solvedPuzzle;//solved puzzle is now shuffled
  return;
}

inline void printComputerMoveInfo( input move ){
  switch( move ){
    case d:
      cout << "Computer made a move down" << endl;
      break;
    case u:
      cout << "Computer made a move up" << endl;
      break;
    case l:
      cout << "Computer made a move to the left" << endl;
      break;
    case r:
      cout << "Computer made a move to the right" << endl;
      break;
  }

  return;
}
void solvePuzzle( int** puzzle, int ROWS, int COLUMNS, int& empty_row, int& empty_col, int& move_count ){
  input curr_move = none;
  input prev_move = none;
  input inverse_move = none;
  int num_of_moves_comp = 0;
  const int MAX_MOVES = 100000;
  while( manhattanDistance( puzzle, ROWS, COLUMNS ) != 0 && num_of_moves_comp <= MAX_MOVES ){
    curr_move = setIntelligentMove( puzzle, ROWS, COLUMNS, &empty_row, &empty_col );
    inverse_move = getInvMove( curr_move );

    if( prev_move == inverse_move ){//means it started repeating the intelligent move
      int rand_moves = ROWS + COLUMNS;
      for( int i = ROWS; i < rand_moves ; ++ i ){
        printComputerMoveInfo( makeRandomMove( puzzle, ROWS, COLUMNS, empty_row, empty_col ) );//makeRandomMove returns the directoins in which it will go
        printPuzzle( puzzle, ROWS, COLUMNS );
        ++ num_of_moves_comp;
        }

      prev_move = none;//reseting it
    }
    else{
      updatePuzzle( &empty_row, &empty_col, curr_move, puzzle );
      printComputerMoveInfo( curr_move );
      printPuzzle( puzzle, ROWS, COLUMNS );
      ++ num_of_moves_comp;
      prev_move = curr_move;
    }
  }
  if( num_of_moves_comp > MAX_MOVES )
    cout << "Unfortuntely, our algorithm has reached the maximum number of moves." << endl << "You can try solving it again or shuffling it( P.S. shuffling makes an easier puzzle :) since it uses random moves instead of random swaps ) and than solving it" << endl << "Good luck!" << endl;

  move_count += num_of_moves_comp;
}

input getInvMove( input move ){
  input inv_move = none;
  switch( move ){
    case d:
      inv_move = u;
      break;
    case u:
      inv_move = d;
      break;
    case l:
      inv_move = r;
      break;
    case r:
      inv_move = l;
      break;
  }

  return inv_move;
}
