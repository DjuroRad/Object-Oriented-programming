#include "BoardArray2D.h"
namespace boardgtu{
BoardArray2D :: BoardArray2D( int rows, int cols ):AbstractBoard( rows, cols ){
  allocatePuzzleAndReset();
}

BoardArray2D :: ~BoardArray2D(){
  for( int i = 0; i < getRows(); ++i )
  delete[] puzzle[ i ];

  delete[] puzzle;
  puzzle = nullptr;
}

BoardArray2D :: BoardArray2D( const BoardArray2D& obj ){
  AbstractBoard :: setSize( obj.getRows(), obj.getCols() );//sets new size for the puzzle, avoiding unnecessary reseting this way
  allocatePuzzle();//allocated it dynamically
  //sets other elements to the same values
  setEmptyCol( obj.getEmptyCol() );
  setEmptyRow( obj.getEmptyRow() );
  setNumberOfMoves( obj.NumberOfMoves() );
  setLastMove( obj.lastMove() );

  for( int i = 0; i < getRows(); ++i )
    for( int j = 0; j < getCols(); ++j )
    this -> puzzle [ i ][ j ] = obj.puzzle[ i ][ j ];
}

const BoardArray2D& BoardArray2D :: operator = ( const BoardArray2D& rightSide ){
  if( this != &rightSide ){
    for( int i = 0; i < getRows(); ++i )
    delete[] puzzle[ i ];

    delete[] puzzle;

    AbstractBoard :: setSize( rightSide.getRows(), rightSide.getCols() );//sets new size for the puzzle, avoiding unnecessary reseting this way
    allocatePuzzle();//allocated it dynamically
    //sets other elements
    setEmptyCol( rightSide.getEmptyCol() );
    setEmptyRow( rightSide.getEmptyRow() );
    setNumberOfMoves( rightSide.NumberOfMoves() );
    setLastMove( rightSide.lastMove() );

    for( int i = 0; i < getRows(); ++i )
      for( int j = 0; j < getCols(); ++j )
      this -> puzzle [ i ][ j ] = rightSide.puzzle[ i ][ j ];
  }

  return *this;
}

void BoardArray2D :: setSize( int rows, int columns ){
  AbstractBoard :: setSize( rows, columns );
  allocatePuzzleAndReset();
}
int BoardArray2D :: operator()( int row, int column )const{
  if( row >= 0 && row < getRows() && column >= 0 && column < getCols() )
    return puzzle[ row ][ column ];
  else exit( 1 );//it says we need to terminate a program, i would use exception but since we didn't learn i'll just use exit here
}
int& BoardArray2D :: operator()( int row, int column ){
  if( row >= 0 && row < getRows() && column >= 0 && column < getCols() )
    return puzzle[ row ][ column ];
  else exit( 1 );//it says we need to terminate a program, i would use exception but since we didn't learn i'll just use exit here
}

void BoardArray2D :: allocatePuzzle(){
  puzzle = new int*[ getRows() ];
  for( int i = 0; i < getRows(); ++i )
    puzzle[ i ] = new int[ getCols() ];

  for( int i = 0; i < getRows(); ++i )//making sure intial value of all the elements is EMPTY_CELL or -1
  fill( puzzle[ i ], puzzle[ i ] + getCols(), ( int )EMPTY_CELL );
}

}//end of namespace
