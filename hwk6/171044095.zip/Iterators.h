#ifndef ITERATORS_H
#define ITERATORS_H
#include "LList.h"
#include <iostream>
namespace stl_gtu{

/*
  Things implemented in ITERATORS.h file:
  GTUIteratorConst
  GTUIterator
  Global functions for Iterators
  Helper function for testing Iterators

  Same iterator works for both vector and Set. It could have been put as a nested classs of a container class they derive from but since there are only to structores and no complications with our iterators i decided to write them like this
  GTUIteratorConst is the base class of the GTUIterator( they are the same so I just implemented it like this with the differene -> and * overloaded operators for GTUIteratorConst )
*/
template < typename T >
class GTUIteratorConst{
public:
  GTUIteratorConst( std :: shared_ptr < Node < T > > iterator = nullptr ): node_iter( iterator ){}//To construct an iterator a shared pointer to node which points to the head of the linked list should be passed and this is used when making an iterator in .begin of the classes derving form Container class
  virtual const T& operator*()const final{  return this -> node_iter.get()->el; }//enables access to the element and changes it since it returns a reference
  virtual const GTUIteratorConst& operator++() final ;//moves iterator to next node and returns modified node
  virtual const GTUIteratorConst operator++( int ignore ) final ;//moves iterator to next node and returns previous state of a node
  virtual const GTUIteratorConst& operator--() final ;//moves iterator to prev node and returns modified node
  virtual const GTUIteratorConst operator--( int ignore ) final ;//moves iterator to pred node and returns previous state of a node
  virtual const GTUIteratorConst& operator =( const GTUIteratorConst& rightSide ) final { node_iter = rightSide.node_iter; return *this; }//just makes an assignment of two iterators and returns that iterator
  virtual bool operator ==( const GTUIteratorConst< T >& rightSide )const  final { if( node_iter == rightSide.node_iter ) return true;else return false; }//(i know i could have written it as a not inline but i was sleepy don't cut points hocam ahahah )checks if two iterators are the same by looking at the address they are pointing to
  virtual bool operator !=( const GTUIteratorConst< T >& rightSide )const final { return !(*this == rightSide); }//just returns negative of the assignment to be able to use our usual for loops for iterators
protected:
  std :: shared_ptr < Node < T > > node_iter;//keeps an address of a node that is part of the linked list since both of our structures use linked list to keep their data
};
//GTUIterator
//It just inherits form its Const as to say relative and implements a couple of new functions unique for it
template < typename T >
class GTUIterator : public GTUIteratorConst < T > {
public:
  GTUIterator( std :: shared_ptr < Node < T > > iterator = nullptr ):GTUIteratorConst< T >( iterator ){}
  Node < T >* operator ->(){ return this->node_iter.get(); }//returns the pointer to the node of course, to access its data iter->el will be needed
  T& operator*(){  return this -> node_iter.get()->el; }//enables access to the element and changes it since it returns a reference
};
//GTUIterator
//Global functions for GTUIterator defined and implemented here( note that they are very similar to the ones in the stl library even though i didn't exactly copy it from there it is just that they are the same what can i do )
template< class GTUIterator, class Function >
Function for_each( GTUIterator first, GTUIterator last, Function f ){
  while( first != last ){
    f( *first );
    ++first;
  }

  return f;
}
template<class GTUIterator, class UnaryPredicate>
GTUIterator find_if (GTUIterator first, GTUIterator last, UnaryPredicate predicate)
{
  while( first != last ){
    if( predicate( *first ) )
      return first;
    ++first;
  }

  return last;//if there is no el satisfying the predicate function it will just return the last element
}
template< typename T >
const GTUIterator< T > find( const GTUIterator < T >& first, const GTUIterator < T >& last, const T& key ){
  bool found = false;
  GTUIterator< T > temp = first;
  while( temp != last && !found ){
    if( *temp == key )
      found = true;
    else
      ++temp;
  }

  if( found )
    return temp;
  else
    return GTUIterator< T >( nullptr );
}
bool isOdd(int i){//used for driver testing
  return i%2;
}
bool isEven(int i){//used for driver testing
  return i%2==0;
}
void printx2( int i ){//used for driver testing
  std :: cout << i*2 << " " << std :: endl;
}
// END OF GLOBAL FUNC IMPLEMENTATION and their helper functions used in driver

//Here just implementation of some functoin pretty much self explainatory
template < typename T >
const GTUIteratorConst< T >& GTUIteratorConst < T > :: operator++(){
  node_iter = node_iter.get() -> next;
  return *this;
}
template < typename T >
const GTUIteratorConst< T > GTUIteratorConst < T > :: operator++( int ignore ){
  GTUIteratorConst< T > to_return( node_iter );
  node_iter = node_iter.get() -> next;
  return to_return;
}
template < typename T >
const GTUIteratorConst< T >& GTUIteratorConst < T > :: operator--(){
  node_iter = node_iter.get() -> prev;
  return *this;
}
template < typename T >
const GTUIteratorConst< T > GTUIteratorConst < T > :: operator--( int ignore ){
  GTUIteratorConst< T > to_return( node_iter );
  node_iter = node_iter.get() -> prev;
  return to_return;
}
}//end of namespace
#endif
