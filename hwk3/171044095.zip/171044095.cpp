#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <ctime>
#include "NPuzzle.h"
using namespace std;

int main( int argc, char** argv ){

  srand( time( NULL ) );
  NPuzzle puzzle_obj;
  if( argc <= 1 ){
    int rows, columns;
    rows = columns = puzzle_obj.setSizeInput();
    puzzle_obj.setSize( rows, columns );
  }
  else
    puzzle_obj.readFromFile( argv[ 1 ] );

  puzzle_obj.print();
  char user_move = puzzle_obj.getMoveFromUser();
  while( user_move != 'Q' ){
    puzzle_obj.move( user_move );
    puzzle_obj.print();
    user_move = puzzle_obj.getMoveFromUser();
  }

  return 0;
}
