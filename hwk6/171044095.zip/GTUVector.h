#include "GTUSet.h"
#ifndef GTUVECTOR_H
#define GTUVECTOR_H

/*
  GTUSet.h implements its structure also using a linked LList
  It will work the same with the exception of( that is how i understood yusuf hoca )
  [] operator
  insert function
  Note*** it is also not sorted
*/
//Here vector is implemented
//It is said that both are deriving form Container class which is still true here since Set is derived from the container
//There is just no need to write it separately since all the things are the same even though there is a 'is' a relationship which is here partially sure with exception of just a couple of functoins
namespace stl_gtu{
template < typename T >
class GTUVector : public GTUSet< T >{
public:
  virtual ~GTUVector(){ this->clear(); }
  T& operator[]( int i );//can change value
  const T& operator[]( int i )const;//can't change value
  void insert( const T& el ){//implemented here
    if( this -> size() >= this -> max_size() )
      throw bad_param();
    else
      this->my_data.get()->insert(el);
  }
  void insert( const T& el, const GTUIteratorConst<T>& iter ){
    if( this -> size() < this->max_size() ){//finds the position and than executes
      GTUIteratorConst<T> temp(this->my_data.get()->head);
      int pos = 0;
      while( iter != temp ){
        ++temp;
        ++pos;
      }
      this->my_data.get()->insert( el, pos );

    }
    else
      throw bad_param();
  }
};
template < typename T >
T& GTUVector< T > :: operator[]( int i ){//the same as for the const just can be altered
  std :: shared_ptr < Node < T > > temp = this -> my_data.get() -> head;
  bool found = false;
  for( int j = 0; !found && j<i; ++j )
    temp = temp.get()->next;

  return temp.get()->el;
}

template < typename T >
const T& GTUVector< T > :: operator[]( int i )const{//returns data at the certain index
  std :: shared_ptr < Node < T > > temp = this -> my_data.get() -> head;
  bool found = false;
  for( int i = 1; !found && i < GTUVector ::  my_data.get() -> getSize(); ++i )//finding the node it is at
    temp = temp.get()->next;

  return temp.get()->el;//returns the reference to the element of the node
}

}//end of namespace
#endif
